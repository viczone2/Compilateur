package fr.aethoria.events.client.ui;

import fr.aethoria.events.client.ClientState;
import fr.aethoria.events.client.ClientState.Act;
import fr.aethoria.events.client.ClientState.CTeam;
import net.minecraft.client.gui.screens.Screen;

public final class TeamsScreen extends BaseScreen {
    public TeamsScreen(Screen back) { super("Équipes", back); }

    @Override protected String subtitle() { return ClientState.teams.size() + " équipe(s)"; }

    @Override
    protected void build() {
        ScrollList l = list(cx(), cy(), cw(), ch() - 28);
        for (CTeam t : ClientState.teams) {
            l.rows.add(new CardRow().icon(UI.banner(t.color)).accent(t.rgb()).title(t.color + t.name)
                    .line(t.members.size() + " joueur(s) · " + t.classes.size() + " classe(s)")
                    .line("Respawn : " + (t.respawn.isEmpty() ? "§cmanquant" : "§aok") + "  §7Drapeau : " + (t.flag.isEmpty() ? "aucun" : "§aok"))
                    .badge("Modifier ›", UI.MUTED)
                    .onClick(() -> minecraft.setScreen(new TeamEditScreen(this, t.name))));
        }
        if (ClientState.teams.isEmpty()) label(cx() + 6, cy() + 8, "Aucune équipe. Crée-en une ci-dessous.", UI.MUTED);
        btn(cx(), cy() + ch() - 22, cw(), 20, "+ Nouvelle équipe", UiButton.Style.PRIMARY, () ->
                minecraft.setScreen(new PromptScreen("Nouvelle équipe", "Nom de l'équipe", "", this, n -> Act.of("team.create").s("name", n).send())));
    }
}
