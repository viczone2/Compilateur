package fr.aethoria.events.client.ui;

import fr.aethoria.events.client.ClientState;
import fr.aethoria.events.client.ClientState.CRank;
import net.minecraft.client.gui.GuiGraphics;

/** Classement de la manche et statistiques cumulees. */
public final class StatsScreen extends BaseScreen {
    private int tab;

    public StatsScreen() { super("Statistiques", null); }

    @Override protected int panelW() { return 400; }
    @Override protected int panelH() { return 290; }

    @Override
    protected void build() {
        tabs(cx(), cy(), cw(), new String[]{"Classement de la manche", ClientState.statsSelf ? "Mes statistiques" : "Stats de " + ClientState.statsName}, () -> tab, i -> tab = i);
    }

    @Override
    protected void renderContent(GuiGraphics g, int mx, int my, float pt) {
        int x = cx(), y = cy() + 28, w = cw();
        if (tab == 0) {
            UI.text(g, "Joueur", x + 28, y + 2, UI.MUTED);
            String[] h = {"K", "D", "Z", "F", "Score"};
            int[] hx = {w - 150, w - 118, w - 86, w - 54, w - 8};
            for (int i = 0; i < h.length; i++) { if (i == 4) UI.textR(g, h[i], x + hx[i], y + 2, UI.MUTED); else UI.textC(g, h[i], x + hx[i], y + 2, UI.MUTED); }
            int ry = y + 14, i = 0;
            for (CRank r : ClientState.ranking) {
                if (ry + 16 > py + ph - 34) break;
                UI.fillRound(g, x, ry, w, 15, 3, r.me ? UI.mix(UI.CARD, UI.GOLD, 0.18f) : UI.CARD);
                UI.fillRound(g, x, ry + 2, 3, 11, 1, r.rgb);
                UI.text(g, "#" + (++i), x + 8, ry + 4, i <= 3 ? UI.GOLD : UI.MUTED);
                UI.text(g, UI.fit(r.name, w - 200), x + 28, ry + 4, UI.TEXT);
                for (int c = 0; c < 4; c++) UI.textC(g, String.valueOf(r.v[c]), x + hx[c], ry + 4, UI.TEXT);
                UI.textR(g, String.valueOf(r.v[0] * 3 + r.v[2] * 5 + r.v[3] * 10), x + hx[4], ry + 4, UI.GOLD);
                ry += 17;
            }
            if (ClientState.ranking.isEmpty()) UI.text(g, "Aucune donnée pour la manche en cours.", x + 4, y + 20, UI.MUTED);
            UI.text(g, "K kills · D morts · Z zones · F drapeaux · Score = 3K + 5Z + 10F", x, py + ph - 42, 0xFF5E667A);
        } else {
            int[] t = ClientState.statsTotal;
            String[] names = {"Kills", "Morts", "Ratio K/D", "Zones capturées", "Drapeaux ramenés", "Manches / victoires"};
            String[] vals = {String.valueOf(t[0]), String.valueOf(t[1]), fr.aethoria.events.client.ui.StatsScreen.kd(t[0], t[1]),
                    String.valueOf(t[2]), String.valueOf(t[3]), t[4] + " / " + t[5]};
            int tw = (w - 8) / 3;
            for (int i = 0; i < 6; i++) {
                int tx = x + (i % 3) * (tw + 4), ty = y + (i / 3) * 52;
                UI.fillRound(g, tx, ty, tw, 46, 5, UI.CARD);
                UI.textC(g, vals[i], tx + tw / 2, ty + 10, UI.GOLD);
                UI.textC(g, names[i], tx + tw / 2, ty + 29, UI.MUTED);
            }
            int[] s = ClientState.statsSession;
            UI.text(g, s == null ? "Manche en cours : pas de participation." : "Manche en cours : " + s[0] + " K · " + s[1] + " D · " + s[2] + " zones · " + s[3] + " drapeaux", x, y + 112, UI.TEXT);
        }
    }

    static String kd(int k, int d) { return String.format(java.util.Locale.ROOT, "%.2f", d == 0 ? (double) k : (double) k / d); }
}
