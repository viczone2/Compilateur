package fr.aethoria.events;

import com.mojang.logging.LogUtils;
import fr.aethoria.events.net.Net;
import net.minecraftforge.fml.common.Mod;
import org.slf4j.Logger;

@Mod(AethoriaEvents.MODID)
public class AethoriaEvents {
    public static final String MODID = "aethoriaevents";
    public static final Logger LOG = LogUtils.getLogger();

    public AethoriaEvents() {
        Net.init();
    }
}
