package fr.aethoria.events.client;

import fr.aethoria.events.client.ui.BaseScreen;
import fr.aethoria.events.client.ui.Screens;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;

/** Points d'entree cote client appeles par les paquets. */
public final class ClientHooks {
    private ClientHooks() {}

    public static void snapshot(CompoundTag tag) {
        Minecraft mc = Minecraft.getInstance();
        ClientState.apply(tag);
        String open = tag.getString("open");
        if (!open.isEmpty()) {
            Screen s = Screens.create(open);
            if (s != null) mc.setScreen(s);
            return;
        }
        if (mc.screen instanceof BaseScreen) ((BaseScreen) mc.screen).refresh();
    }

    public static void hud(CompoundTag tag) { ClientState.setHud(tag); }
}
