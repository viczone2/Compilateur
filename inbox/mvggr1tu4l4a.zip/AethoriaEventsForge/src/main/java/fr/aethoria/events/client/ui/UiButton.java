package fr.aethoria.events.client.ui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import java.util.ArrayList;
import java.util.List;

/** Bouton plat avec animation de survol, icone d'objet, sous-titre et confirmation optionnelle. */
public class UiButton extends AbstractWidget {
    public enum Style { NORMAL, PRIMARY, SUCCESS, DANGER, GHOST }

    private final Runnable action;
    private final Style style;
    private String label;
    private ItemStack icon = ItemStack.EMPTY;
    private String sub = "";
    private boolean selected, confirm;
    private long armedUntil;
    private List<Component> tip = new ArrayList<>();
    private float anim;

    public UiButton(int x, int y, int w, int h, String label, Style style, Runnable action) {
        super(x, y, w, h, Component.literal(label));
        this.label = label; this.style = style; this.action = action;
    }

    public UiButton icon(ItemStack s) { icon = s; return this; }
    public UiButton sub(String s) { sub = s; return this; }
    public UiButton selected(boolean b) { selected = b; return this; }
    public UiButton confirm() { confirm = true; return this; }
    public UiButton enabled(boolean b) { active = b; return this; }
    public UiButton tip(String... lines) { tip = new ArrayList<>(); for (String l : lines) tip.add(Component.literal(l)); return this; }
    public List<Component> tooltip() { return tip; }
    public void setLabel(String s) { label = s; setMessage(Component.literal(s)); }

    @Override
    public void renderWidget(GuiGraphics g, int mx, int my, float pt) {
        boolean hov = active && isHoveredOrFocused();
        anim += ((hov ? 1f : 0f) - anim) * 0.4f;
        int base, hi;
        switch (style) {
            case PRIMARY: base = 0xFF7A5E1A; hi = UI.GOLD_DK; break;
            case SUCCESS: base = 0xFF1B6B4B; hi = 0xFF258A61; break;
            case DANGER: base = 0xFF7D2A27; hi = 0xFFA13632; break;
            case GHOST: base = 0x00000000; hi = 0x33FFFFFF; break;
            default: base = UI.CARD; hi = UI.CARD_HI;
        }
        int bg = UI.mix(base, hi, anim);
        if (!active) bg = UI.mix(bg, UI.PANEL, 0.6f);
        int x = getX(), y = getY();
        if (selected) UI.roundBorder(g, x, y, width, height, 4, UI.GOLD, bg);
        else UI.fillRound(g, x, y, width, height, 4, bg);
        boolean armed = confirm && System.currentTimeMillis() < armedUntil;
        String text = armed ? "Confirmer ?" : label;
        int tc = active ? (armed ? UI.WARN : UI.TEXT) : UI.MUTED;
        boolean big = height >= 36;
        int tx = x + width / 2;
        if (!icon.isEmpty()) {
            if (big) {
                UI.drawItem(g, icon, x + 8, y + (height - 28) / 2, 1.75f);
                int lx = x + 44;
                UI.text(g, UI.fit(text, width - 52), lx, y + (sub.isEmpty() ? (height - 8) / 2 : height / 2 - 10), tc);
                if (!sub.isEmpty()) UI.text(g, UI.fit(sub, width - 52), lx, y + height / 2 + 2, UI.MUTED);
                return;
            }
            UI.drawItem(g, icon, x + 4, y + (height - 16) / 2, 1f);
            UI.text(g, UI.fit(text, width - 26), x + 24, y + (height - 8) / 2, tc);
            return;
        }
        if (!sub.isEmpty()) {
            UI.textC(g, UI.fit(text, width - 8), tx, y + height / 2 - 9, tc);
            UI.textC(g, UI.fit(sub, width - 8), tx, y + height / 2 + 2, UI.MUTED);
        } else UI.textC(g, UI.fit(text, width - 8), tx, y + (height - 8) / 2, tc);
    }

    @Override
    public void onClick(double mx, double my) {
        if (!active) return;
        if (confirm) {
            long now = System.currentTimeMillis();
            if (now >= armedUntil) { armedUntil = now + 3000; return; }
            armedUntil = 0;
        }
        action.run();
    }

    @Override
    public void updateWidgetNarration(NarrationElementOutput out) { defaultButtonNarrationText(out); }
}
