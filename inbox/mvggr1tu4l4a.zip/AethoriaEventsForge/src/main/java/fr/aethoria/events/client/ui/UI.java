package fr.aethoria.events.client.ui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import fr.aethoria.events.Opts;
import net.minecraft.ChatFormatting;
import net.minecraft.world.level.block.BannerBlock;
import net.minecraftforge.registries.ForgeRegistries;
import java.util.HashMap;
import java.util.Map;

/** Theme et primitives de dessin communes a toutes les interfaces. */
public final class UI {
    private UI() {}

    public static final int DIM = 0xC0070910;
    public static final int PANEL = 0xFF161A25, PANEL_HI = 0xFF1D2230, CARD = 0xFF212736, CARD_HI = 0xFF2C3549, LINE = 0xFF343C52;
    public static final int GOLD = 0xFFE3B341, GOLD_DK = 0xFF8F6F1F, TEXT = 0xFFEDF0F7, MUTED = 0xFF8C95A8;
    public static final int GOOD = 0xFF4CC38A, BAD = 0xFFE5534B, WARN = 0xFFE8A23D;

    public static Font font() { return Minecraft.getInstance().font; }

    public static boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    public static int mix(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int aa = (int) (((a >>> 24) & 255) * (1 - t) + ((b >>> 24) & 255) * t);
        int ar = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int ag = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int ab = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (aa << 24) | (ar << 16) | (ag << 8) | ab;
    }

    public static void fillRound(GuiGraphics g, int x, int y, int w, int h, int r, int color) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) { g.fill(x, y, x + w, y + h, color); return; }
        g.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(Math.max(0, r * r - dy * dy)));
            g.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            g.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
        }
    }

    public static void roundBorder(GuiGraphics g, int x, int y, int w, int h, int r, int border, int fill) {
        fillRound(g, x, y, w, h, r, border);
        fillRound(g, x + 1, y + 1, w - 2, h - 2, Math.max(0, r - 1), fill);
    }

    public static void text(GuiGraphics g, String s, int x, int y, int color) { g.drawString(font(), s, x, y, color, false); }

    public static void textC(GuiGraphics g, String s, int cx, int y, int color) { g.drawString(font(), s, cx - font().width(s) / 2, y, color, false); }

    public static void textR(GuiGraphics g, String s, int rx, int y, int color) { g.drawString(font(), s, rx - font().width(s), y, color, false); }

    public static String fit(String s, int maxW) {
        Font f = font();
        if (f.width(s) <= maxW) return s;
        return f.plainSubstrByWidth(s, Math.max(0, maxW - f.width("…"))) + "…";
    }

    public static void drawSwitch(GuiGraphics g, int x, int y, boolean on) {
        fillRound(g, x, y, 24, 12, 6, on ? GOOD : 0xFF3A4156);
        int kx = on ? x + 13 : x + 1;
        fillRound(g, kx, y + 1, 10, 10, 5, 0xFFF4F6FB);
    }

    public static void drawItem(GuiGraphics g, ItemStack s, int x, int y, float scale) {
        if (s == null || s.isEmpty()) return;
        if (scale == 1f) { g.renderItem(s, x, y); return; }
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(scale, scale, 1f);
        g.renderItem(s, 0, 0);
        g.pose().popPose();
    }

    private static final Map<String, ItemStack> ICONS = new HashMap<>();

    public static ItemStack icon(String id) {
        return ICONS.computeIfAbsent(id, k -> {
            ResourceLocation rl = ResourceLocation.tryParse(k);
            Item it = rl == null ? null : ForgeRegistries.ITEMS.getValue(rl);
            return new ItemStack(it == null || it == Items.AIR ? Items.BARRIER : it);
        });
    }

    public static ItemStack banner(ChatFormatting c) { return new ItemStack(BannerBlock.byColor(Opts.dye(c))); }

    public static void click() {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
    }

    public static String mmss(long ms) {
        long s = Math.max(0, ms / 1000);
        return String.format("%02d:%02d", s / 60, s % 60);
    }
}
