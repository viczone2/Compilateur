package fr.aethoria.events.client.ui;

import fr.aethoria.events.client.ClientState;
import fr.aethoria.events.client.ClientState.Act;
import fr.aethoria.events.client.ClientState.CKit;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.registries.ForgeRegistries;
import java.util.*;

/** Catalogue de tous les objets (vanilla + mods) avec recherche et filtre par mod : clic = ajoute au kit. */
public final class CatalogScreen extends BaseScreen {
    private static List<ItemStack> ALL;
    private static List<String> KEYS;
    private static Map<String, Integer> NS;

    private static void load() {
        if (ALL != null) return;
        List<ResourceLocation> ids = new ArrayList<>(ForgeRegistries.ITEMS.getKeys());
        ids.sort((a, b) -> {
            boolean am = a.getNamespace().equals("minecraft"), bm = b.getNamespace().equals("minecraft");
            if (am != bm) return am ? -1 : 1;
            int c = a.getNamespace().compareTo(b.getNamespace());
            return c != 0 ? c : a.getPath().compareTo(b.getPath());
        });
        ALL = new ArrayList<>(); KEYS = new ArrayList<>(); NS = new LinkedHashMap<>();
        for (ResourceLocation id : ids) {
            Item it = ForgeRegistries.ITEMS.getValue(id);
            if (it == null || it == Items.AIR) continue;
            ItemStack s = new ItemStack(it);
            ALL.add(s);
            KEYS.add((id.toString() + " " + s.getHoverName().getString()).toLowerCase(Locale.ROOT));
            NS.merge(id.getNamespace(), 1, Integer::sum);
        }
    }

    private final String kitName;
    private String query = "", ns = "";
    private final List<ItemStack> filtered = new ArrayList<>();
    private int scrollRow;
    private EditBox box;

    public CatalogScreen(Screen back, String kitName) { super("Catalogue d'objets", back); this.kitName = kitName; load(); refilter(); }

    @Override protected int panelH() { return 304; }
    @Override protected int panelW() { return 470; }
    @Override protected String subtitle() { CKit k = ClientState.kit(kitName); return "Kit " + kitName + (k == null ? "" : " · " + k.items.size() + "/45"); }

    private void refilter() {
        filtered.clear();
        String q = query.toLowerCase(Locale.ROOT).trim();
        for (int i = 0; i < ALL.size(); i++) {
            ItemStack s = ALL.get(i);
            if (!ns.isEmpty() && !ForgeRegistries.ITEMS.getKey(s.getItem()).getNamespace().equals(ns)) continue;
            if (!q.isEmpty() && !KEYS.get(i).contains(q)) continue;
            filtered.add(s);
        }
        scrollRow = 0;
    }

    private int gx() { return cx() + 118; }
    private int gy() { return cy() + 26; }
    private int cols() { return Math.max(1, (cw() - 118 - 6) / 20); }
    private int rows() { return Math.max(1, (ch() - 26) / 20); }

    @Override
    protected void build() {
        box = new EditBox(font, cx(), cy(), 230, 18, Component.literal("Recherche"));
        box.setMaxLength(40);
        box.setValue(query);
        box.setResponder(s -> { query = s; refilter(); });
        addRenderableWidget(box);
        setInitialFocus(box);
        ScrollList l = list(cx(), gy(), 112, ch() - 26);
        l.gap = 2;
        l.rows.add(modRow("", "Tous les mods", ALL.size()));
        for (Map.Entry<String, Integer> e : NS.entrySet()) l.rows.add(modRow(e.getKey(), e.getKey(), e.getValue()));
    }

    private ScrollList.Row modRow(String key, String label, int count) {
        return new ScrollList.Row() {
            @Override public int height() { return 18; }
            @Override public void render(GuiGraphics g, int x, int y, int w, int mx, int my, boolean hover) {
                boolean sel = ns.equals(key);
                UI.fillRound(g, x, y, w, 18, 3, sel ? UI.GOLD_DK : hover ? UI.CARD_HI : UI.CARD);
                UI.text(g, UI.fit(label, w - 34), x + 5, y + 5, UI.TEXT);
                UI.textR(g, String.valueOf(count), x + w - 4, y + 5, UI.MUTED);
            }
            @Override public boolean click(int rx, int ry, int w, int button) { UI.click(); ns = key; refilter(); return true; }
        };
    }

    @Override
    protected void renderContent(GuiGraphics g, int mx, int my, float pt) {
        UI.text(g, filtered.size() + " objet(s)", cx() + 238, cy() + 5, UI.MUTED);
        int cols = cols(), rows = rows();
        int maxRow = Math.max(0, (filtered.size() + cols - 1) / cols - rows);
        scrollRow = Math.max(0, Math.min(maxRow, scrollRow));
        for (int r = 0; r < rows; r++) for (int c = 0; c < cols; c++) {
            int idx = (scrollRow + r) * cols + c;
            int x = gx() + c * 20, y = gy() + r * 20;
            boolean hov = UI.in(mx, my, x, y, 18, 18);
            UI.fillRound(g, x, y, 18, 18, 3, hov && idx < filtered.size() ? UI.CARD_HI : UI.CARD);
            if (idx < filtered.size()) g.renderItem(filtered.get(idx), x + 1, y + 1);
        }
        if (maxRow > 0) {
            int bh = Math.max(16, (rows * 20) * rows / (rows + maxRow));
            int by = gy() + (int) ((rows * 20 - bh) * ((double) scrollRow / maxRow));
            UI.fillRound(g, gx() + cols * 20 + 1, by, 3, bh, 1, UI.GOLD_DK);
        }
        UI.text(g, "Gauche +1 · Droit +16 · Maj = pile complète", gx(), gy() + rows * 20 + 3, 0xFF5E667A);
    }

    private int idxAt(double mx, double my) {
        int cols = cols(), rows = rows();
        if (!UI.in(mx, my, gx(), gy(), cols * 20, rows * 20)) return -1;
        int c = ((int) mx - gx()) / 20, r = ((int) my - gy()) / 20;
        int i = (scrollRow + r) * cols + c;
        return i < filtered.size() ? i : -1;
    }

    @Override
    protected void renderLate(GuiGraphics g, int mx, int my) {
        int i = idxAt(mx, my);
        if (i >= 0) g.renderTooltip(font, filtered.get(i), mx, my);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        int i = idxAt(mx, my);
        if (i < 0) return false;
        ItemStack s = filtered.get(i);
        int count = hasShiftDown() ? s.getMaxStackSize() : button == 1 ? Math.min(16, s.getMaxStackSize()) : 1;
        UI.click();
        Act.of("kit.add").s("name", kitName).s("item", ForgeRegistries.ITEMS.getKey(s.getItem()).toString()).n("count", count).send();
        return true;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        if (UI.in(mx, my, gx(), gy(), cols() * 20 + 6, rows() * 20)) { scrollRow -= (int) Math.signum(delta) * 2; return true; }
        return super.mouseScrolled(mx, my, delta);
    }
}
