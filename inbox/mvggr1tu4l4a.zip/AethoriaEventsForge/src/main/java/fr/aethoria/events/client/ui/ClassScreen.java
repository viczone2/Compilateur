package fr.aethoria.events.client.ui;

import fr.aethoria.events.client.ClientState;
import fr.aethoria.events.client.ClientState.Act;
import fr.aethoria.events.client.ClientState.CKit;
import fr.aethoria.events.client.ClientState.CTeam;
import net.minecraft.world.item.ItemStack;
import java.util.ArrayList;
import java.util.List;

/** Choix de classe pour les joueurs de l'evenement. */
public final class ClassScreen extends BaseScreen {
    public ClassScreen() { super("Choisis ta classe", null); }

    @Override protected int panelW() { return 380; }
    @Override protected int panelH() { return 290; }

    @Override
    protected String subtitle() {
        CTeam t = ClientState.team(ClientState.myTeam);
        return t == null ? "" : "Équipe " + t.color + t.name;
    }

    @Override
    protected void build() {
        CTeam t = ClientState.team(ClientState.myTeam);
        ScrollList l = list(cx(), cy(), cw(), ch());
        if (t == null) { label(cx() + 6, cy() + 8, "Tu n'as pas d'équipe.", UI.MUTED); return; }
        for (String cn : t.classes) {
            CKit k = ClientState.kit(cn);
            if (k == null) continue;
            boolean mine = k.name.equals(ClientState.myChoice);
            int lim = k.limit > 0 ? k.limit : ClientState.setting("default-class-limit");
            boolean full = lim > 0 && k.taken >= lim && !mine;
            CardRow r = new CardRow().icon(k.icon()).accent(mine ? UI.GOOD : full ? UI.BAD : UI.GOLD_DK).title(k.name)
                    .line("Pris : " + k.taken + (lim > 0 ? "/" + lim : "") + " · " + k.items.size() + " objet(s)");
            if (k.medic) r.line("§aMédecin : accroupi près d'un allié à terre pour le relever");
            if (mine) r.badge("ÉQUIPÉE", UI.GOOD); else if (full) r.badge("Complet", UI.BAD); else r.badge("Choisir", UI.MUTED);
            List<String> tip = new ArrayList<>();
            tip.add("§e" + k.name);
            for (ItemStack s : k.items) tip.add("§7" + s.getCount() + "x " + s.getHoverName().getString());
            r.tip(tip);
            if (!full) r.onClick(() -> { Act.of("class.choose").s("kit", k.name).send(); minecraft.setScreen(null); });
            l.rows.add(r);
        }
        if (l.rows.isEmpty()) label(cx() + 6, cy() + 8, "Aucune classe disponible pour ton équipe.", UI.MUTED);
    }
}
