package fr.aethoria.events;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import java.util.*;

/** Construit l'etat complet envoye aux interfaces client. */
public final class Snapshots {
    private Snapshots() {}

    public static CompoundTag build(ServerPlayer p, UUID statsTarget) {
        Game g = Game.I;
        CompoundTag t = new CompoundTag();
        if (g == null) return t;
        long now = System.currentTimeMillis();
        t.putBoolean("op", p.hasPermissions(2));
        t.putBoolean("running", g.running);
        t.putBoolean("deploying", g.deploying());
        t.putLong("ms", g.running ? Math.max(0, (g.deploying() ? g.deployUntil : g.endMs) - now) : 0);

        CompoundTag set = new CompoundTag();
        for (Map.Entry<String, Integer> e : g.st.settings.entrySet()) set.putInt(e.getKey(), e.getValue());
        t.put("settings", set);

        ListTag teams = new ListTag();
        for (EvTeam e : g.st.teams.values()) {
            CompoundTag c = new CompoundTag();
            c.putString("name", e.name);
            c.putString("color", e.color.getName());
            c.putString("respawn", e.respawn == null ? "" : e.respawn.pretty());
            c.putString("flag", e.flag == null ? "" : e.flag.pretty());
            c.putInt("points", e.points);
            ListTag cl = new ListTag();
            for (String k : e.classes) cl.add(StringTag.valueOf(k));
            c.put("classes", cl);
            ListTag ml = new ListTag();
            for (UUID u : e.members) {
                ServerPlayer mp = g.player(u);
                CompoundTag m = new CompoundTag();
                m.putString("uuid", u.toString());
                m.putString("name", mp != null ? mp.getGameProfile().getName() : g.stats.names.getOrDefault(u, "?"));
                m.putBoolean("online", mp != null);
                ml.add(m);
            }
            c.put("members", ml);
            teams.add(c);
        }
        t.put("teams", teams);

        EvTeam mine = g.teamOf(p.getUUID());
        ListTag kits = new ListTag();
        for (EvKit k : g.st.kits.values()) {
            CompoundTag c = new CompoundTag();
            c.putString("name", k.name);
            c.putInt("limit", k.limit);
            c.putBoolean("medic", k.medic);
            ListTag il = new ListTag();
            for (ItemStack s : k.items) il.add(s.save(new CompoundTag()));
            c.put("items", il);
            int taken = 0;
            if (mine != null) for (UUID u : mine.members) if (k.name.equals(g.choice.get(u))) taken++;
            c.putInt("taken", taken);
            kits.add(c);
        }
        t.put("kits", kits);

        ListTag zones = new ListTag();
        for (EvZone z : g.st.zones.values()) {
            CompoundTag c = new CompoundTag();
            c.putString("name", z.name);
            c.putString("type", z.type);
            c.putDouble("radius", z.radius);
            c.putInt("seconds", z.seconds);
            c.putString("center", z.center == null ? "" : z.center.pretty());
            c.putString("hq", z.hq == null ? "" : z.hq);
            c.putString("owner", z.owner == null ? "" : z.owner);
            zones.add(c);
        }
        t.put("zones", zones);

        ListTag players = new ListTag();
        for (ServerPlayer o : g.server.getPlayerList().getPlayers()) {
            EvTeam ot = g.teamOf(o.getUUID());
            CompoundTag c = new CompoundTag();
            c.putString("uuid", o.getUUID().toString());
            c.putString("name", o.getGameProfile().getName());
            c.putString("team", ot == null ? "" : ot.name);
            players.add(c);
        }
        t.put("players", players);

        CompoundTag me = new CompoundTag();
        me.putString("team", mine == null ? "" : mine.name);
        String ch = g.choice.get(p.getUUID());
        me.putString("choice", ch == null ? "" : ch);
        t.put("me", me);

        // statistiques
        CompoundTag stats = new CompoundTag();
        UUID target = statsTarget != null ? statsTarget : p.getUUID();
        stats.putString("targetName", target.equals(p.getUUID()) ? p.getGameProfile().getName() : g.stats.names.getOrDefault(target, "?"));
        stats.putBoolean("self", target.equals(p.getUUID()));
        int[] tot = g.stats.totals(target);
        stats.putIntArray("total", tot.clone());
        int[] ses = g.stats.sess(target);
        if (ses != null) stats.putIntArray("session", ses.clone());
        ListTag rank = new ListTag();
        int i = 0;
        for (Map.Entry<UUID, int[]> e : g.stats.ranking()) {
            if (i++ >= 15) break;
            CompoundTag c = new CompoundTag();
            c.putString("name", g.stats.sessionNames.getOrDefault(e.getKey(), "?"));
            c.putIntArray("v", e.getValue().clone());
            c.putBoolean("me", e.getKey().equals(p.getUUID()));
            EvTeam rt = g.teamOf(e.getKey());
            c.putInt("rgb", rt == null ? 0xFFFFFF : Opts.rgb(rt.color));
            rank.add(c);
        }
        stats.put("rank", rank);
        t.put("stats", stats);
        return t;
    }
}
