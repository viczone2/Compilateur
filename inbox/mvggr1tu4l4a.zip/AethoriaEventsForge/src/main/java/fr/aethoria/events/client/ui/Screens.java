package fr.aethoria.events.client.ui;

import net.minecraft.client.gui.screens.Screen;

/** Fabrique des ecrans ouverts a la demande du serveur. */
public final class Screens {
    private Screens() {}

    public static Screen create(String id) {
        if (id.equals("main")) return new MainScreen(null);
        if (id.equals("class")) return new ClassScreen();
        if (id.equals("stats")) return new StatsScreen();
        if (id.startsWith("kit:")) return new KitEditScreen(new KitsScreen(new MainScreen(null)), id.substring(4));
        return null;
    }
}
