package fr.aethoria.events.client.ui;

import fr.aethoria.events.client.ClientState;
import fr.aethoria.events.client.ClientState.Act;
import fr.aethoria.events.client.ClientState.CTeam;
import fr.aethoria.events.client.ClientState.CZone;
import net.minecraft.client.gui.screens.Screen;

public final class ZoneEditScreen extends BaseScreen {
    private String name;

    public ZoneEditScreen(Screen back, String name) { super("Zone", back); this.name = name; }

    @Override protected String subtitle() { return name; }

    @Override
    protected void build() {
        CZone z = ClientState.zone(name);
        if (z == null) { label(cx() + 6, cy() + 8, "Zone introuvable.", UI.MUTED); return; }
        int y = cy();
        label(cx(), y + 2, "Type de zone", UI.MUTED);
        String[] types = {"NORMAL", "DEPOT", "HQ"}, names = {"Normale", "Dépôt", "QG"};
        int tw = (cw() - 8) / 3;
        for (int i = 0; i < 3; i++) {
            final String t = types[i];
            btn(cx() + i * (tw + 4), y + 14, tw, 20, names[i], UiButton.Style.NORMAL, () -> Act.of("zone.type").s("name", name).s("type", t).send()).selected(z.type.equals(t));
        }
        String desc = z.type.equals("HQ") ? "QG : l'équipe attaquante doit posséder des zones, puis tenir le QG pour gagner."
                : z.type.equals("DEPOT") ? "Dépôt : l'équipe qui le tient peut se ravitailler avec /ravitaillement."
                : "Normale : rapporte des points à l'équipe qui la contrôle.";
        label(cx(), y + 40, UI.fit(desc, cw()), UI.MUTED);
        int sy = y + 56;
        if (z.type.equals("HQ")) {
            label(cx(), sy + 2, "Équipe qui défend ce QG", UI.TEXT);
            int n = ClientState.teams.size() + 1, cwid = Math.min(100, (cw() - (n - 1) * 4) / n);
            btn(cx(), sy + 14, cwid, 18, "Aucune", UiButton.Style.NORMAL, () -> Act.of("zone.hq").s("name", name).s("team", "").send()).selected(z.hq.isEmpty());
            int i = 1;
            for (CTeam t : ClientState.teams) {
                btn(cx() + i * (cwid + 4), sy + 14, cwid, 18, t.color + t.name, UiButton.Style.NORMAL, () -> Act.of("zone.hq").s("name", name).s("team", t.name).send())
                        .selected(z.hq.equalsIgnoreCase(t.name));
                i++;
            }
            sy += 40;
        }
        stepper(cx(), sy + 4, cw(), "Rayon", String.valueOf((int) z.radius), 1, 5, d -> Act.of("zone.radius").s("name", name).n("delta", d).send());
        stepper(cx(), sy + 30, cw(), "Temps de capture (s)", String.valueOf(z.seconds), 5, 30, d -> Act.of("zone.seconds").s("name", name).n("delta", d).send());
        label(cx(), sy + 60, "Centre : " + (z.center.isEmpty() ? "?" : z.center), UI.MUTED);
        int bw = (cw() - 8) / 3, by = sy + 74;
        btn(cx(), by, bw, 20, "Déplacer ici", UiButton.Style.SUCCESS, () -> Act.of("zone.move").s("name", name).send());
        btn(cx() + bw + 4, by, bw, 20, "Se téléporter", UiButton.Style.NORMAL, () -> Act.of("zone.tp").s("name", name).send());
        btn(cx() + 2 * (bw + 4), by, bw, 20, "Supprimer", UiButton.Style.DANGER, () -> { Act.of("zone.delete").s("name", name).send(); minecraft.setScreen(back); }).confirm();
        btn(cx(), by + 24, cw(), 20, "Renommer la zone", UiButton.Style.NORMAL, () ->
                minecraft.setScreen(new PromptScreen("Renommer la zone", "Nouveau nom", z.name, this, n -> { Act.of("zone.rename").s("name", name).s("new", n).send(); name = n; })));
    }
}
