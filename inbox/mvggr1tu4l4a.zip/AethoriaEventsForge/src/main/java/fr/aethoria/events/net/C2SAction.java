package fr.aethoria.events.net;

import fr.aethoria.events.Actions;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

public class C2SAction {
    private final String action;
    private final CompoundTag args;

    public C2SAction(String action, CompoundTag args) { this.action = action; this.args = args == null ? new CompoundTag() : args; }

    public void encode(FriendlyByteBuf buf) { buf.writeUtf(action, 64); buf.writeNbt(args); }

    public static C2SAction decode(FriendlyByteBuf buf) {
        String a = buf.readUtf(64);
        CompoundTag t = buf.readNbt();
        return new C2SAction(a, t);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        ServerPlayer sender = c.getSender();
        c.enqueueWork(() -> { if (sender != null) Actions.handle(sender, action, args); });
        c.setPacketHandled(true);
    }
}
