package fr.aethoria.events;

import com.google.gson.JsonObject;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;

/** Position (dimension + coordonnees), serialisable. */
public final class Loc {
    public final String dim;
    public final double x, y, z;
    public final float yaw, pitch;

    public Loc(String dim, double x, double y, double z, float yaw, float pitch) {
        this.dim = dim; this.x = x; this.y = y; this.z = z; this.yaw = yaw; this.pitch = pitch;
    }

    static String dimOf(Entity e) { return e.level().dimension().location().toString(); }

    /** Position exacte du joueur (point de respawn, centre de zone). */
    public static Loc of(ServerPlayer p) { return new Loc(dimOf(p), p.getX(), p.getY(), p.getZ(), p.getYRot(), p.getXRot()); }

    /** Bloc sous les pieds du joueur (drapeau). */
    public static Loc block(ServerPlayer p) {
        BlockPos b = p.blockPosition();
        return new Loc(dimOf(p), b.getX(), b.getY(), b.getZ(), 0f, 0f);
    }

    public ServerLevel level(MinecraftServer s) {
        return s.getLevel(ResourceKey.create(Registries.DIMENSION, new ResourceLocation(dim)));
    }

    public BlockPos pos() { return BlockPos.containing(x, y, z); }

    public boolean sameDim(Entity e) { return dimOf(e).equals(dim); }

    public void teleport(ServerPlayer p) {
        ServerLevel l = level(p.server);
        if (l != null) p.teleportTo(l, x, y, z, yaw, pitch);
    }

    public String pretty() {
        return dim.replace("minecraft:", "") + " " + (int) Math.floor(x) + " " + (int) Math.floor(y) + " " + (int) Math.floor(z);
    }

    public JsonObject toJson() {
        JsonObject o = new JsonObject();
        o.addProperty("dim", dim); o.addProperty("x", x); o.addProperty("y", y); o.addProperty("z", z);
        o.addProperty("yaw", yaw); o.addProperty("pitch", pitch);
        return o;
    }

    public static Loc fromJson(JsonObject o) {
        if (o == null) return null;
        try {
            return new Loc(o.get("dim").getAsString(), o.get("x").getAsDouble(), o.get("y").getAsDouble(), o.get("z").getAsDouble(),
                    o.has("yaw") ? o.get("yaw").getAsFloat() : 0f, o.has("pitch") ? o.get("pitch").getAsFloat() : 0f);
        } catch (Exception e) { return null; }
    }
}
