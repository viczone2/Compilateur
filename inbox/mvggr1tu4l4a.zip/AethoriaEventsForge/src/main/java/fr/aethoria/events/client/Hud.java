package fr.aethoria.events.client;

import fr.aethoria.events.client.ui.UI;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Interface de jeu : chronometre, scores des equipes, zones, classe, etat "a terre". */
public final class Hud {
    private Hud() {}

    private static int c(int rgb) { return 0xFF000000 | rgb; }

    public static void render(GuiGraphics g, int w, int h) {
        CompoundTag t = ClientState.hud;
        Minecraft mc = Minecraft.getInstance();
        if (t == null || mc.options.hideGui || mc.player == null) return;
        long left = Math.max(0, t.getLong("ms") - (System.currentTimeMillis() - ClientState.hudAt));
        boolean deploy = t.getBoolean("deploy");

        // chronometre
        String time = UI.mmss(left);
        String label = deploy ? "DÉPLOIEMENT" : "COMBAT";
        int tw = 112, tx = (w - tw) / 2, ty = 6;
        UI.fillRound(g, tx, ty, tw, 24, 6, 0xC0101420);
        UI.fillRound(g, tx, ty + 3, 3, 18, 1, deploy ? UI.WARN : UI.BAD);
        UI.drawItem(g, new ItemStack(deploy ? Items.CLOCK : Items.IRON_SWORD), tx + 8, ty + 4, 1f);
        UI.text(g, label, tx + 28, ty + 4, deploy ? UI.WARN : UI.MUTED);
        g.pose().pushPose();
        g.pose().translate(tx + 28, ty + 13, 0);
        g.pose().scale(1.0f, 1.0f, 1f);
        UI.text(g, "§l" + time, 0, 0, UI.TEXT);
        g.pose().popPose();

        // scores
        int total = 0;
        for (Tag e : t.getList("teams", Tag.TAG_COMPOUND)) total += UI.font().width(((CompoundTag) e).getString("name") + " " + ((CompoundTag) e).getInt("points")) + 26;
        int sx = (w - total) / 2, sy = ty + 28;
        UI.fillRound(g, sx - 4, sy, total + 4, 16, 5, 0xB0101420);
        int x = sx + 4;
        for (Tag e : t.getList("teams", Tag.TAG_COMPOUND)) {
            CompoundTag team = (CompoundTag) e;
            String s = team.getString("name") + " " + team.getInt("points");
            UI.fillRound(g, x, sy + 4, 8, 8, 2, c(team.getInt("rgb")));
            UI.text(g, s, x + 12, sy + 4, UI.TEXT);
            if (team.getBoolean("stolen")) UI.text(g, "§c!", x + 14 + UI.font().width(s), sy + 4, UI.BAD);
            x += UI.font().width(s) + 26;
        }

        // classe
        String cls = t.getString("class");
        if (!cls.isEmpty()) UI.textC(g, "§7Classe : §f" + cls, w / 2, sy + 21, UI.MUTED);

        // zones
        int zy = 40, zx = w - 134;
        for (Tag e : t.getList("zones", Tag.TAG_COMPOUND)) {
            CompoundTag z = (CompoundTag) e;
            UI.fillRound(g, zx, zy, 128, 24, 4, 0xB0101420);
            int owner = z.getInt("owner"), captor = z.getInt("captor");
            UI.fillRound(g, zx + 5, zy + 5, 6, 6, 3, owner < 0 ? 0xFF6B7285 : c(owner));
            UI.text(g, UI.fit((z.getBoolean("hq") ? "QG " : "") + z.getString("name"), 108), zx + 15, zy + 4, UI.TEXT);
            float p = z.getFloat("progress");
            boolean hold = z.getInt("hold") > 0;
            if (hold) p = Math.min(1f, z.getInt("hold") / (float) z.getInt("need"));
            int barCol = hold ? c(owner < 0 ? 0xFFFFFF : owner) : captor >= 0 ? c(captor) : owner >= 0 ? c(owner) : 0xFF3A4156;
            UI.fillRound(g, zx + 6, zy + 16, 116, 4, 2, 0xFF262C3D);
            float fill = (captor >= 0 || hold) ? p : (owner >= 0 ? 1f : 0f);
            if (fill > 0) UI.fillRound(g, zx + 6, zy + 16, Math.max(3, (int) (116 * fill)), 4, 2, barCol);
            zy += 28;
        }

        // a terre
        long down = t.getLong("downedMs");
        if (down > 0) {
            long rem = Math.max(0, down - (System.currentTimeMillis() - ClientState.hudAt));
            g.fill(0, 0, w, h, 0x22FF0000);
            UI.textC(g, "§c§lÀ TERRE §7- mort dans " + (rem / 1000 + 1) + "s", w / 2, h - 70, UI.BAD);
        }
    }
}
