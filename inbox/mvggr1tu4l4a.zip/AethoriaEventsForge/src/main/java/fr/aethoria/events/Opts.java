package fr.aethoria.events;

import net.minecraft.ChatFormatting;
import net.minecraft.world.item.DyeColor;
import java.util.List;

/** Reglages de l'evenement (cle, libelle, icone, pas, minimum, defaut) + utilitaires de couleur. */
public final class Opts {
    private Opts() {}

    public static final class Opt {
        public final String key, label, icon, group;
        public final int step, min, def;

        Opt(String key, String label, String icon, int step, int min, int def, String group) {
            this.key = key; this.label = label; this.icon = icon; this.step = step; this.min = min; this.def = def; this.group = group;
        }

        /** Un pas de 0 signifie un reglage oui / non. */
        public boolean bool() { return step == 0; }
    }

    public static final String G_GAME = "Partie", G_RESPAWN = "Réapparition et soutien", G_SCORE = "Points et zones";

    public static final List<Opt> ALL = List.of(
            new Opt("deploy-minutes", "Déploiement sans combat (min)", "minecraft:clock", 1, 0, 0, G_GAME),
            new Opt("duration-minutes", "Durée du combat (min)", "minecraft:clock", 5, 1, 15, G_GAME),
            new Opt("score-limit", "Limite de score (0 = aucune)", "minecraft:golden_sword", 10, 0, 100, G_GAME),
            new Opt("friendly-fire", "Tir allié", "minecraft:iron_sword", 0, 0, 0, G_GAME),
            new Opt("join-late", "Rejoindre en cours de partie", "minecraft:oak_door", 0, 0, 1, G_GAME),
            new Opt("respawn-delay", "Délai de réapparition (s)", "minecraft:red_bed", 1, 0, 5, G_RESPAWN),
            new Opt("protection-seconds", "Protection après réapparition (s)", "minecraft:shield", 1, 0, 5, G_RESPAWN),
            new Opt("revive", "À terre + réanimation par le médecin", "minecraft:golden_apple", 0, 0, 1, G_RESPAWN),
            new Opt("revive-seconds", "Temps avant de mourir à terre (s)", "minecraft:clock", 5, 5, 30, G_RESPAWN),
            new Opt("revive-hold-seconds", "Durée de la réanimation (s)", "minecraft:clock", 1, 1, 4, G_RESPAWN),
            new Opt("resupply-cooldown", "Délai entre deux ravitaillements (s)", "minecraft:chest", 30, 0, 120, G_RESPAWN),
            new Opt("default-class-limit", "Limite de classe par défaut (0 = aucune)", "minecraft:book", 1, 0, 0, G_RESPAWN),
            new Opt("kill-points", "Points par kill", "minecraft:skeleton_skull", 1, 0, 0, G_SCORE),
            new Opt("zone-points", "Points par zone possédée", "minecraft:beacon", 1, 0, 1, G_SCORE),
            new Opt("zone-points-interval", "Intervalle des points de zone (s)", "minecraft:repeater", 10, 1, 5, G_SCORE),
            new Opt("zone-capture-points", "Bonus de capture de zone", "minecraft:nether_star", 1, 0, 5, G_SCORE),
            new Opt("flag-capture-points", "Points par drapeau ramené", "minecraft:white_banner", 1, 0, 1, G_SCORE),
            new Opt("max-zones-per-team", "Zones max par équipe (0 = aucune limite)", "minecraft:map", 1, 0, 0, G_SCORE),
            new Opt("hq-required-zones", "Zones requises pour attaquer un QG", "minecraft:target", 1, 0, 2, G_SCORE),
            new Opt("hq-hold-seconds", "Durée à tenir le QG pour gagner (s)", "minecraft:clock", 10, 5, 60, G_SCORE),
            new Opt("zone-outline", "Contour de couleur des zones", "minecraft:lime_dye", 0, 0, 1, G_SCORE)
    );

    public static Opt get(String key) {
        for (Opt o : ALL) if (o.key.equals(key)) return o;
        return null;
    }

    /** Couleurs proposees pour les equipes. */
    public static final ChatFormatting[] PALETTE = {
            ChatFormatting.RED, ChatFormatting.BLUE, ChatFormatting.GREEN, ChatFormatting.YELLOW, ChatFormatting.GOLD,
            ChatFormatting.AQUA, ChatFormatting.LIGHT_PURPLE, ChatFormatting.DARK_PURPLE, ChatFormatting.DARK_GREEN,
            ChatFormatting.DARK_AQUA, ChatFormatting.DARK_RED, ChatFormatting.DARK_BLUE, ChatFormatting.GRAY, ChatFormatting.WHITE
    };

    public static int rgb(ChatFormatting c) {
        Integer v = c == null ? null : c.getColor();
        return v == null ? 0xFFFFFF : v;
    }

    public static DyeColor dye(ChatFormatting c) {
        switch (c) {
            case BLACK: return DyeColor.BLACK;
            case DARK_BLUE: return DyeColor.BLUE;
            case DARK_GREEN: return DyeColor.GREEN;
            case DARK_AQUA: return DyeColor.CYAN;
            case DARK_RED: return DyeColor.BROWN;
            case DARK_PURPLE: return DyeColor.PURPLE;
            case GOLD: return DyeColor.ORANGE;
            case GRAY: return DyeColor.LIGHT_GRAY;
            case DARK_GRAY: return DyeColor.GRAY;
            case BLUE: return DyeColor.LIGHT_BLUE;
            case GREEN: return DyeColor.LIME;
            case AQUA: return DyeColor.CYAN;
            case RED: return DyeColor.RED;
            case LIGHT_PURPLE: return DyeColor.MAGENTA;
            case YELLOW: return DyeColor.YELLOW;
            default: return DyeColor.WHITE;
        }
    }

    public static ChatFormatting parseColor(String n) {
        if (n == null) return null;
        ChatFormatting c = ChatFormatting.getByName(n);
        return c != null && c.isColor() ? c : null;
    }
}
