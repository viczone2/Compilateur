package fr.aethoria.events.client;

import fr.aethoria.events.net.C2SAction;
import fr.aethoria.events.net.Net;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.item.ItemStack;
import java.util.*;

/** Etat cote client, alimente par les paquets du serveur. */
public final class ClientState {
    private ClientState() {}

    public static final class CPlayer { public String name, uuid, team; public boolean online; }

    public static final class CTeam {
        public String name = "", respawn = "", flag = "";
        public ChatFormatting color = ChatFormatting.WHITE;
        public int points;
        public final List<String> classes = new ArrayList<>();
        public final List<CPlayer> members = new ArrayList<>();
        public int rgb() { Integer c = color.getColor(); return 0xFF000000 | (c == null ? 0xFFFFFF : c); }
    }

    public static final class CKit {
        public String name = "";
        public int limit, taken;
        public boolean medic;
        public final List<ItemStack> items = new ArrayList<>();
        public ItemStack icon() { return items.isEmpty() ? new ItemStack(net.minecraft.world.item.Items.IRON_SWORD) : items.get(0); }
    }

    public static final class CZone {
        public String name = "", type = "NORMAL", center = "", hq = "", owner = "";
        public double radius;
        public int seconds;
    }

    public static final class CRank { public String name; public int[] v = new int[4]; public boolean me; public int rgb; }

    public static boolean op, running, deploying;
    public static long ms, msAt;
    public static final Map<String, Integer> settings = new HashMap<>();
    public static final List<CTeam> teams = new ArrayList<>();
    public static final List<CKit> kits = new ArrayList<>();
    public static final List<CZone> zones = new ArrayList<>();
    public static final List<CPlayer> players = new ArrayList<>();
    public static String myTeam = "", myChoice = "";
    public static String statsName = "";
    public static boolean statsSelf = true;
    public static int[] statsTotal = new int[6];
    public static int[] statsSession = null;
    public static final List<CRank> ranking = new ArrayList<>();

    public static String toast;
    public static boolean toastOk;
    public static long toastUntil;

    public static CompoundTag hud;
    public static long hudAt;

    public static CTeam team(String n) { for (CTeam t : teams) if (t.name.equalsIgnoreCase(n)) return t; return null; }
    public static CKit kit(String n) { for (CKit k : kits) if (k.name.equalsIgnoreCase(n)) return k; return null; }
    public static CZone zone(String n) { for (CZone z : zones) if (z.name.equalsIgnoreCase(n)) return z; return null; }
    public static int setting(String k) { return settings.getOrDefault(k, 0); }

    public static long remainingMs() { return Math.max(0, ms - (System.currentTimeMillis() - msAt)); }

    public static void apply(CompoundTag t) {
        op = t.getBoolean("op"); running = t.getBoolean("running"); deploying = t.getBoolean("deploying");
        ms = t.getLong("ms"); msAt = System.currentTimeMillis();
        settings.clear();
        CompoundTag set = t.getCompound("settings");
        for (String k : set.getAllKeys()) settings.put(k, set.getInt(k));

        teams.clear();
        for (Tag e : t.getList("teams", Tag.TAG_COMPOUND)) {
            CompoundTag c = (CompoundTag) e;
            CTeam x = new CTeam();
            x.name = c.getString("name");
            ChatFormatting f = ChatFormatting.getByName(c.getString("color"));
            if (f != null) x.color = f;
            x.respawn = c.getString("respawn"); x.flag = c.getString("flag"); x.points = c.getInt("points");
            for (Tag k : c.getList("classes", Tag.TAG_STRING)) x.classes.add(k.getAsString());
            for (Tag m : c.getList("members", Tag.TAG_COMPOUND)) {
                CompoundTag mc = (CompoundTag) m;
                CPlayer p = new CPlayer();
                p.uuid = mc.getString("uuid"); p.name = mc.getString("name"); p.online = mc.getBoolean("online"); p.team = x.name;
                x.members.add(p);
            }
            teams.add(x);
        }

        kits.clear();
        for (Tag e : t.getList("kits", Tag.TAG_COMPOUND)) {
            CompoundTag c = (CompoundTag) e;
            CKit k = new CKit();
            k.name = c.getString("name"); k.limit = c.getInt("limit"); k.medic = c.getBoolean("medic"); k.taken = c.getInt("taken");
            for (Tag i : c.getList("items", Tag.TAG_COMPOUND)) {
                ItemStack s = ItemStack.of((CompoundTag) i);
                if (!s.isEmpty()) k.items.add(s);
            }
            kits.add(k);
        }

        zones.clear();
        for (Tag e : t.getList("zones", Tag.TAG_COMPOUND)) {
            CompoundTag c = (CompoundTag) e;
            CZone z = new CZone();
            z.name = c.getString("name"); z.type = c.getString("type"); z.radius = c.getDouble("radius"); z.seconds = c.getInt("seconds");
            z.center = c.getString("center"); z.hq = c.getString("hq"); z.owner = c.getString("owner");
            zones.add(z);
        }

        players.clear();
        for (Tag e : t.getList("players", Tag.TAG_COMPOUND)) {
            CompoundTag c = (CompoundTag) e;
            CPlayer p = new CPlayer();
            p.uuid = c.getString("uuid"); p.name = c.getString("name"); p.team = c.getString("team"); p.online = true;
            players.add(p);
        }

        CompoundTag me = t.getCompound("me");
        myTeam = me.getString("team"); myChoice = me.getString("choice");

        CompoundTag st = t.getCompound("stats");
        statsName = st.getString("targetName"); statsSelf = st.getBoolean("self");
        statsTotal = st.getIntArray("total");
        if (statsTotal.length < 6) statsTotal = Arrays.copyOf(statsTotal, 6);
        statsSession = st.contains("session") ? st.getIntArray("session") : null;
        if (statsSession != null && statsSession.length < 4) statsSession = Arrays.copyOf(statsSession, 4);
        ranking.clear();
        for (Tag e : st.getList("rank", Tag.TAG_COMPOUND)) {
            CompoundTag c = (CompoundTag) e;
            CRank r = new CRank();
            r.name = c.getString("name"); r.me = c.getBoolean("me"); r.rgb = 0xFF000000 | c.getInt("rgb");
            int[] v = c.getIntArray("v");
            r.v = v.length >= 4 ? v : Arrays.copyOf(v, 4);
            ranking.add(r);
        }

        if (t.contains("toast")) { toast = t.getString("toast"); toastOk = t.getBoolean("toastOk"); toastUntil = System.currentTimeMillis() + 3500; }
    }

    public static void setHud(CompoundTag t) { hud = t; hudAt = System.currentTimeMillis(); }

    // ------------------------------------------------------------------ envoi d'actions
    public static final class Act {
        private final String a; private final CompoundTag t = new CompoundTag();
        private Act(String a) { this.a = a; }
        public static Act of(String a) { return new Act(a); }
        public Act s(String k, String v) { t.putString(k, v); return this; }
        public Act n(String k, int v) { t.putInt(k, v); return this; }
        public Act b(String k, boolean v) { t.putBoolean(k, v); return this; }
        public void send() { Net.toServer(new C2SAction(a, t)); }
    }
}
