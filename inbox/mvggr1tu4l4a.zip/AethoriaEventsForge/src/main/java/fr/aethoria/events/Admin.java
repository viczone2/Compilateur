package fr.aethoria.events;

import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import java.util.ArrayList;
import java.util.List;

/**
 * Operations d'administration partagees entre les commandes et l'interface graphique.
 * Chaque methode renvoie un message ; un message qui commence par "!" est une erreur.
 */
public final class Admin {
    private Admin() {}

    static final int MAX_ITEMS = 45;

    static String err(String s) { return "!" + s; }
    public static boolean isErr(String r) { return r != null && r.startsWith("!"); }
    public static String text(String r) { return isErr(r) ? r.substring(1) : r; }

    private static Game g() { return Game.I; }
    private static boolean locked() { return g().running; }
    private static String lockedMsg() { return err("Impossible pendant un événement en cours."); }

    static boolean validName(String n) { return n != null && n.matches("[\\p{L}\\p{N}_-]{1,24}"); }
    static final String BAD_NAME = "Nom invalide (1 à 24 caractères : lettres, chiffres, _ ou -, sans espace).";

    // ------------------------------------------------------------------ equipes
    public static String teamCreate(String name) {
        Store st = g().st;
        if (locked()) return lockedMsg();
        if (!validName(name)) return err(BAD_NAME);
        if (st.team(name) != null) return err("Ce nom d'équipe existe déjà.");
        EvTeam t = new EvTeam(name);
        t.color = Opts.PALETTE[st.teams.size() % Opts.PALETTE.length];
        st.teams.put(t.name, t); st.save();
        return "Équipe " + t.colored() + " créée.";
    }

    public static String teamDelete(String name) {
        Store st = g().st;
        if (locked()) return lockedMsg();
        EvTeam t = st.team(name);
        if (t == null) return err("Équipe introuvable.");
        st.teams.remove(t.name);
        for (EvZone z : st.zones.values()) if (z.hq != null && z.hq.equalsIgnoreCase(t.name)) z.hq = null;
        st.save();
        return "Équipe supprimée.";
    }

    public static String teamRename(String name, String nn) {
        Store st = g().st;
        if (locked()) return lockedMsg();
        EvTeam t = st.team(name);
        if (t == null) return err("Équipe introuvable.");
        if (!validName(nn)) return err(BAD_NAME);
        EvTeam other = st.team(nn);
        if (other != null && other != t) return err("Ce nom d'équipe existe déjà.");
        String old = t.name;
        // on reconstruit la map pour conserver l'ordre
        List<EvTeam> list = new ArrayList<>(st.teams.values());
        st.teams.clear();
        t.name = nn;
        for (EvTeam x : list) st.teams.put(x.name, x);
        for (EvZone z : st.zones.values()) if (z.hq != null && z.hq.equalsIgnoreCase(old)) z.hq = nn;
        st.save();
        return "Équipe renommée en " + t.colored() + ".";
    }

    public static String teamColor(String name, ChatFormatting c) {
        EvTeam t = g().st.team(name);
        if (t == null) return err("Équipe introuvable.");
        if (c == null || !c.isColor()) return err("Couleur invalide.");
        if (locked()) return lockedMsg();
        t.color = c; g().st.save();
        return "Couleur modifiée : " + t.colored();
    }

    public static String teamSpawn(String name, ServerPlayer p) {
        EvTeam t = g().st.team(name);
        if (t == null) return err("Équipe introuvable.");
        t.respawn = Loc.of(p); g().st.save();
        return "Respawn de " + t.colored() + " §fdéfini ici.";
    }

    public static String teamFlag(String name, ServerPlayer p, boolean clear) {
        EvTeam t = g().st.team(name);
        if (t == null) return err("Équipe introuvable.");
        if (locked()) return lockedMsg();
        if (clear) { t.flag = null; g().st.save(); return "Drapeau retiré."; }
        t.flag = Loc.block(p); g().st.save();
        return "Drapeau de " + t.colored() + " §fdéfini ici.";
    }

    public static String teamClass(String name, String kit) {
        EvTeam t = g().st.team(name); EvKit k = g().st.kit(kit);
        if (t == null || k == null) return err("Équipe ou kit introuvable.");
        if (t.classes.contains(k.name)) t.classes.remove(k.name); else t.classes.add(k.name);
        g().st.save();
        return t.classes.contains(k.name) ? "Classe " + k.name + " activée." : "Classe " + k.name + " désactivée.";
    }

    /** team == null : retire le joueur de son equipe. Si deja dans cette equipe, le retire aussi. */
    public static String teamMember(ServerPlayer target, String team) {
        Game g = g();
        EvTeam cur = g.teamOf(target.getUUID());
        EvTeam dest = team == null || team.isEmpty() ? null : g.st.team(team);
        if (team != null && !team.isEmpty() && dest == null) return err("Équipe introuvable.");
        for (EvTeam x : g.st.teams.values()) x.members.remove(target.getUUID());
        g.auto.remove(target.getUUID());
        String n = target.getGameProfile().getName();
        if (dest == null || dest == cur) return n + " retiré de son équipe.";
        dest.members.add(target.getUUID());
        if (g.running) g.schedule(1, () -> { if (g.running && !target.hasDisconnected()) g.prepare(target); });
        return n + " ajouté à " + dest.colored();
    }

    // ------------------------------------------------------------------ kits
    public static String kitCreate(String name, ServerPlayer from) {
        Store st = g().st;
        if (!validName(name)) return err(BAD_NAME);
        if (st.kit(name) != null) return err("Ce kit existe déjà.");
        EvKit k = new EvKit(name);
        if (from != null) copyInv(k, from);
        st.kits.put(k.name, k); st.save();
        return "Kit " + k.name + " créé" + (from != null ? " à partir de ton inventaire." : ".");
    }

    public static String kitDelete(String name) {
        Store st = g().st;
        if (locked()) return lockedMsg();
        EvKit k = st.kit(name);
        if (k == null) return err("Kit introuvable.");
        st.kits.remove(k.name);
        for (EvTeam t : st.teams.values()) t.classes.remove(k.name);
        st.save();
        return "Kit supprimé.";
    }

    public static String kitRename(String name, String nn) {
        Store st = g().st;
        if (locked()) return lockedMsg();
        EvKit k = st.kit(name);
        if (k == null) return err("Kit introuvable.");
        if (!validName(nn)) return err(BAD_NAME);
        EvKit other = st.kit(nn);
        if (other != null && other != k) return err("Ce nom de kit existe déjà.");
        String old = k.name;
        List<EvKit> list = new ArrayList<>(st.kits.values());
        st.kits.clear();
        k.name = nn;
        for (EvKit x : list) st.kits.put(x.name, x);
        for (EvTeam t : st.teams.values()) for (int i = 0; i < t.classes.size(); i++) if (t.classes.get(i).equals(old)) t.classes.set(i, nn);
        st.save();
        return "Kit renommé en " + nn + ".";
    }

    public static String kitLimit(String name, int delta) {
        EvKit k = g().st.kit(name);
        if (k == null) return err("Kit introuvable.");
        k.limit = Math.max(0, Math.min(99, k.limit + delta)); g().st.save();
        return "";
    }

    public static String kitMedic(String name) {
        EvKit k = g().st.kit(name);
        if (k == null) return err("Kit introuvable.");
        k.medic = !k.medic; g().st.save();
        return k.medic ? "Cette classe peut relever les joueurs à terre." : "Cette classe ne relève plus les joueurs.";
    }

    static void copyInv(EvKit k, ServerPlayer p) {
        k.items.clear();
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (!s.isEmpty() && k.items.size() < MAX_ITEMS) k.items.add(s.copy());
        }
    }

    public static String kitCopyInv(String name, ServerPlayer p) {
        EvKit k = g().st.kit(name);
        if (k == null) return err("Kit introuvable.");
        copyInv(k, p); g().st.save();
        return k.items.size() + " objets copiés depuis ton inventaire.";
    }

    public static String kitClear(String name) {
        EvKit k = g().st.kit(name);
        if (k == null) return err("Kit introuvable.");
        k.items.clear(); g().st.save();
        return "Kit vidé.";
    }

    /** Ajoute count exemplaires de l'objet ; fusionne avec une pile existante identique (sans NBT) quand c'est possible. */
    static String addStack(EvKit k, ItemStack add) {
        int left = add.getCount();
        int max = Math.max(1, add.getMaxStackSize());
        if (!add.hasTag()) {
            for (ItemStack s : k.items) {
                if (left <= 0) break;
                if (s.getItem() == add.getItem() && !s.hasTag() && s.getCount() < max) {
                    int n = Math.min(left, max - s.getCount());
                    s.grow(n); left -= n;
                }
            }
        }
        while (left > 0) {
            if (k.items.size() >= MAX_ITEMS) return err("Kit plein (" + MAX_ITEMS + " emplacements max).");
            ItemStack c = add.copy();
            c.setCount(Math.min(left, max));
            k.items.add(c); left -= c.getCount();
        }
        return "";
    }

    public static String kitAdd(String name, String itemId, int count) {
        EvKit k = g().st.kit(name);
        if (k == null) return err("Kit introuvable.");
        ResourceLocation rl = ResourceLocation.tryParse(itemId);
        Item it = rl == null ? Items.AIR : BuiltInRegistries.ITEM.get(rl);
        if (it == Items.AIR) return err("Objet inconnu : " + itemId);
        String r = addStack(k, new ItemStack(it, Math.max(1, Math.min(count, 64 * 4))));
        if (isErr(r)) return r;
        g().st.save();
        return "";
    }

    public static String kitAddHand(String name, ServerPlayer p) {
        EvKit k = g().st.kit(name);
        if (k == null) return err("Kit introuvable.");
        ItemStack h = p.getMainHandItem();
        if (h.isEmpty()) return err("Tu ne tiens rien en main.");
        String r = addStack(k, h);
        if (isErr(r)) return r;
        g().st.save();
        return "Objet ajouté au kit.";
    }

    /** Change la quantite d'un emplacement ; supprime l'emplacement quand il tombe a 0. */
    public static String kitAdjust(String name, int index, int delta) {
        EvKit k = g().st.kit(name);
        if (k == null) return err("Kit introuvable.");
        if (index < 0 || index >= k.items.size()) return err("Emplacement invalide.");
        ItemStack s = k.items.get(index);
        int max = Math.max(1, s.getMaxStackSize());
        int n = s.getCount() + delta;
        if (n <= 0) k.items.remove(index);
        else s.setCount(Math.min(n, max));
        g().st.save();
        return "";
    }

    public static String kitRemove(String name, int index) {
        EvKit k = g().st.kit(name);
        if (k == null) return err("Kit introuvable.");
        if (index < 0 || index >= k.items.size()) return err("Emplacement invalide.");
        k.items.remove(index); g().st.save();
        return "";
    }

    public static String kitGive(String name, ServerPlayer to) {
        EvKit k = g().st.kit(name);
        if (k == null) return err("Kit introuvable.");
        Game.giveKit(to, k);
        return "Kit " + k.name + " équipé (ton inventaire a été remplacé).";
    }

    // ------------------------------------------------------------------ zones
    public static String zoneCreate(String name, ServerPlayer p, double radius, int seconds) {
        Store st = g().st;
        if (locked()) return lockedMsg();
        if (!validName(name)) return err(BAD_NAME);
        if (st.zone(name) != null) return err("Ce nom de zone existe déjà.");
        EvZone z = new EvZone(name);
        z.center = Loc.of(p); z.radius = radius; z.seconds = seconds;
        st.zones.put(z.name, z); st.save();
        return "Zone " + z.name + " créée ici (rayon " + z.radius + ", " + z.seconds + "s).";
    }

    public static String zoneDelete(String name) {
        Store st = g().st;
        if (locked()) return lockedMsg();
        EvZone z = st.zone(name);
        if (z == null) return err("Zone introuvable.");
        st.zones.remove(z.name); st.save();
        return "Zone supprimée.";
    }

    public static String zoneRename(String name, String nn) {
        Store st = g().st;
        if (locked()) return lockedMsg();
        EvZone z = st.zone(name);
        if (z == null) return err("Zone introuvable.");
        if (!validName(nn)) return err(BAD_NAME);
        EvZone other = st.zone(nn);
        if (other != null && other != z) return err("Ce nom de zone existe déjà.");
        List<EvZone> list = new ArrayList<>(st.zones.values());
        st.zones.clear();
        z.name = nn;
        for (EvZone x : list) st.zones.put(x.name, x);
        st.save();
        return "Zone renommée en " + nn + ".";
    }

    public static String zoneRadius(String name, int delta) {
        EvZone z = g().st.zone(name);
        if (z == null) return err("Zone introuvable.");
        z.radius = Math.max(1, Math.min(200, z.radius + delta)); g().st.save();
        return "";
    }

    public static String zoneSeconds(String name, int delta) {
        EvZone z = g().st.zone(name);
        if (z == null) return err("Zone introuvable.");
        z.seconds = Math.max(1, Math.min(3600, z.seconds + delta)); g().st.save();
        return "";
    }

    public static String zoneType(String name, String type) {
        EvZone z = g().st.zone(name);
        if (z == null) return err("Zone introuvable.");
        if (!type.equals("NORMAL") && !type.equals("DEPOT") && !type.equals("HQ")) return err("Type de zone invalide.");
        if (locked()) return lockedMsg();
        z.type = type;
        if (!"HQ".equals(type)) z.hq = null;
        g().st.save();
        return "";
    }

    public static String zoneHq(String name, String team) {
        EvZone z = g().st.zone(name);
        if (z == null) return err("Zone introuvable.");
        if (locked()) return lockedMsg();
        if (team == null || team.isEmpty()) z.hq = null;
        else {
            EvTeam t = g().st.team(team);
            if (t == null) return err("Équipe introuvable.");
            z.hq = t.name;
        }
        g().st.save();
        return "";
    }

    public static String zoneMove(String name, ServerPlayer p) {
        EvZone z = g().st.zone(name);
        if (z == null) return err("Zone introuvable.");
        z.center = Loc.of(p); g().st.save();
        return "Zone déplacée ici.";
    }

    public static String zoneTp(String name, ServerPlayer p) {
        EvZone z = g().st.zone(name);
        if (z == null) return err("Zone introuvable.");
        z.center.teleport(p);
        return "";
    }

    // ------------------------------------------------------------------ reglages
    public static String setting(String key, int value) {
        Opts.Opt o = Opts.get(key);
        if (o == null) return err("Option inconnue : " + key);
        int v = o.bool() ? (value != 0 ? 1 : 0) : Math.max(o.min, Math.min(100000, value));
        g().st.settings.put(key, v); g().st.save();
        return "";
    }

    // ------------------------------------------------------------------ prereglage Operation Reconquete
    public static String preset() {
        Store st = g().st;
        if (locked()) return lockedMsg();
        Object[][] ks = {{"Fusilier", 5, false}, {"Éclaireur", 2, false}, {"Soutien", 1, false}, {"Ingénieur", 1, false}, {"Médecin", 1, true}};
        for (Object[] k : ks) {
            if (st.kit((String) k[0]) != null) continue;
            EvKit kk = new EvKit((String) k[0]); kk.limit = (Integer) k[1]; kk.medic = (Boolean) k[2];
            st.kits.put(kk.name, kk);
        }
        String[] tn = {"Attaquants", "Défenseurs"};
        ChatFormatting[] tc = {ChatFormatting.RED, ChatFormatting.BLUE};
        for (int i = 0; i < 2; i++) {
            EvTeam t = st.team(tn[i]);
            if (t == null) { t = new EvTeam(tn[i]); t.color = tc[i]; st.teams.put(t.name, t); }
            for (Object[] k : ks) if (!t.classes.contains((String) k[0])) t.classes.add((String) k[0]);
        }
        Object[][] cf = {{"duration-minutes", 60}, {"deploy-minutes", 10}, {"respawn-delay", 15}, {"score-limit", 0}, {"zone-points", 1},
                {"zone-points-interval", 60}, {"zone-capture-points", 0}, {"max-zones-per-team", 2}, {"hq-required-zones", 2},
                {"hq-hold-seconds", 60}, {"flag-capture-points", 1}, {"revive", 1}, {"friendly-fire", 0}};
        for (Object[] c : cf) st.settings.put((String) c[0], (Integer) c[1]);
        st.save();
        return "Préréglage appliqué : 5 classes (Médecin = relève les joueurs), équipes Attaquants / Défenseurs, réglages Opération Reconquête. "
                + "Remplis les kits (Kits > modifier > Copier mon inventaire), place les respawns et crée tes zones.";
    }
}
