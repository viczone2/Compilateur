package fr.aethoria.events.client.ui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import java.util.ArrayList;
import java.util.List;

/** Liste verticale defilante composee de lignes dessinees a la main. */
public final class ScrollList {
    public interface Row {
        int height();
        void render(GuiGraphics g, int x, int y, int w, int mx, int my, boolean hover);
        default boolean click(int rx, int ry, int w, int button) { return false; }
        default List<Component> tooltip(int rx, int ry, int w) { return null; }
    }

    public int x, y, w, h, gap = 3;
    public double scroll;
    public final List<Row> rows = new ArrayList<>();

    public void bounds(int x, int y, int w, int h) { this.x = x; this.y = y; this.w = w; this.h = h; }

    private int contentH() {
        int t = 0;
        for (Row r : rows) t += r.height() + gap;
        return Math.max(0, t - gap);
    }

    private int maxScroll() { return Math.max(0, contentH() - h); }

    private int rowW() { return w - (maxScroll() > 0 ? 7 : 0); }

    public void render(GuiGraphics g, int mx, int my) {
        scroll = Math.max(0, Math.min(maxScroll(), scroll));
        int cw = rowW();
        g.enableScissor(x, y, x + w, y + h);
        int yy = y - (int) scroll;
        for (Row r : rows) {
            int rh = r.height();
            if (yy + rh >= y && yy <= y + h) {
                boolean hover = mx >= x && mx < x + cw && my >= Math.max(y, yy) && my < Math.min(y + h, yy + rh);
                r.render(g, x, yy, cw, mx, my, hover);
            }
            yy += rh + gap;
        }
        g.disableScissor();
        int ms = maxScroll();
        if (ms > 0) {
            int bh = Math.max(16, (int) ((long) h * h / contentH()));
            int by = y + (int) ((h - bh) * (scroll / ms));
            UI.fillRound(g, x + w - 4, y, 3, h, 1, 0xFF232837);
            UI.fillRound(g, x + w - 4, by, 3, bh, 1, UI.GOLD_DK);
        }
    }

    private int[] locate(double mx, double my) {
        if (mx < x || mx >= x + rowW() || my < y || my >= y + h) return null;
        int yy = y - (int) scroll;
        for (int i = 0; i < rows.size(); i++) {
            int rh = rows.get(i).height();
            if (my >= yy && my < yy + rh) return new int[]{i, (int) mx - x, (int) my - yy};
            yy += rh + gap;
        }
        return null;
    }

    public boolean mouseClicked(double mx, double my, int button) {
        int[] l = locate(mx, my);
        if (l == null) return false;
        return rows.get(l[0]).click(l[1], l[2], rowW(), button);
    }

    public boolean mouseScrolled(double mx, double my, double delta) {
        if (mx < x || mx >= x + w || my < y || my >= y + h) return false;
        scroll = Math.max(0, Math.min(maxScroll(), scroll - delta * 20));
        return true;
    }

    public List<Component> tooltipAt(double mx, double my) {
        int[] l = locate(mx, my);
        return l == null ? null : rows.get(l[0]).tooltip(l[1], l[2], rowW());
    }
}
