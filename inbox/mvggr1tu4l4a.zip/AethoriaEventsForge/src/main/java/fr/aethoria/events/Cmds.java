package fr.aethoria.events;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import fr.aethoria.events.net.Net;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.GameType;
import java.util.*;
import java.util.concurrent.CompletableFuture;

/** Commandes : /event (alias /ev), /classe, /ravitaillement (alias /ravit), /stats. */
public final class Cmds {
    private Cmds() {}

    public static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(eventNode("event"));
        d.register(eventNode("ev"));
        d.register(Commands.literal("classe").executes(c -> classe(c.getSource())));
        d.register(Commands.literal("classes").executes(c -> classe(c.getSource())));
        d.register(Commands.literal("ravitaillement").executes(c -> ravit(c.getSource())));
        d.register(Commands.literal("ravit").executes(c -> ravit(c.getSource())));
        d.register(Commands.literal("stats")
                .executes(c -> stats(c.getSource(), null))
                .then(Commands.argument("joueur", StringArgumentType.word())
                        .suggests((c, b) -> suggest(onlineNames(), b, "top"))
                        .executes(c -> stats(c.getSource(), StringArgumentType.getString(c, "joueur")))));
    }

    private static LiteralArgumentBuilder<CommandSourceStack> eventNode(String name) {
        return Commands.literal(name)
                .requires(s -> s.hasPermission(2))
                .executes(c -> { help(c.getSource()); return 1; })
                .then(Commands.argument("args", StringArgumentType.greedyString())
                        .suggests(Cmds::suggestEvent)
                        .executes(c -> exec(c.getSource(), StringArgumentType.getString(c, "args").trim().split("\\s+"))));
    }

    // ------------------------------------------------------------------ utilitaires
    static void msg(CommandSourceStack s, String m) { s.sendSuccess(() -> Component.literal("§6[Event] §f" + m), false); }
    static void fail(CommandSourceStack s, String m) { s.sendFailure(Component.literal("§c" + m)); }

    static void reply(CommandSourceStack s, String r) {
        if (r == null || r.isEmpty()) return;
        if (Admin.isErr(r)) fail(s, Admin.text(r)); else msg(s, r);
    }

    static ServerPlayer playerOf(CommandSourceStack s) { return s.getEntity() instanceof ServerPlayer ? (ServerPlayer) s.getEntity() : null; }

    static List<String> onlineNames() {
        List<String> l = new ArrayList<>();
        if (Game.I != null) for (ServerPlayer p : Game.I.server.getPlayerList().getPlayers()) l.add(p.getGameProfile().getName());
        return l;
    }

    // ------------------------------------------------------------------ commandes joueurs
    static int classe(CommandSourceStack s) {
        ServerPlayer p = playerOf(s); Game g = Game.I;
        if (p == null) { fail(s, "Commande réservée aux joueurs."); return 0; }
        if (g == null || !g.running || g.teamOf(p.getUUID()) == null) { fail(s, "Aucun événement en cours ou pas d'équipe."); return 0; }
        Net.openScreen(p, "class");
        return 1;
    }

    static int ravit(CommandSourceStack s) {
        ServerPlayer p = playerOf(s); Game g = Game.I;
        if (p == null || g == null) { fail(s, "Commande réservée aux joueurs."); return 0; }
        Game.tell(p, g.resupply(p));
        return 1;
    }

    static int stats(CommandSourceStack s, String who) {
        ServerPlayer p = playerOf(s); Game g = Game.I;
        if (p == null || g == null) { fail(s, "Commande réservée aux joueurs."); return 0; }
        UUID target = null;
        if (who != null && !who.equalsIgnoreCase("top")) {
            target = g.stats.find(who, g.server);
            if (target == null) { fail(s, "Joueur inconnu."); return 0; }
        }
        Net.sendSnapshot(p, "stats", target, null, true);
        return 1;
    }

    // ------------------------------------------------------------------ /event
    static void help(CommandSourceStack s) {
        s.sendSuccess(() -> Component.literal("§6§m----§e /event §6§m----"), false);
        String[] l = {
                "§e/event gui §7- ouvre l'interface (équipes, kits, zones, réglages)",
                "§e/event start|stop §7- lancer / arrêter l'événement",
                "§e/event go §7- met fin au déploiement et lance le combat",
                "§e/event preset §7- crée le préréglage Opération Reconquête",
                "§e/event team create|delete|add|remove|spawn|flag|color|list",
                "§e/event zone create <nom> [rayon] [secondes]|delete|list|tp",
                "§e/event kit create|delete|edit|give",
                "§e/event spectate [joueur] §7- mode caméra",
                "§e/event set <option> <valeur> §7- ex : duration-minutes 20",
                "§e/classe §7- choisir sa classe  §e/ravitaillement  §e/stats [joueur]"
        };
        for (String x : l) s.sendSuccess(() -> Component.literal(x), false);
    }

    static int exec(CommandSourceStack s, String[] a) {
        Game g = Game.I;
        if (g == null) { fail(s, "Mod non initialisé."); return 0; }
        ServerPlayer p = playerOf(s);
        String sub = a[0].toLowerCase();
        switch (sub) {
            case "gui": case "menu":
                if (p == null) fail(s, "Joueur uniquement."); else Net.openScreen(p, "main");
                break;
            case "start": { String e = g.start(); if (e != null) fail(s, e); break; }
            case "go": { String e = g.go(); if (e != null) fail(s, e); else msg(s, "Le combat commence !"); break; }
            case "preset": reply(s, Admin.preset()); break;
            case "stop": if (!g.running) fail(s, "Aucun événement en cours."); else g.finish(true); break;
            case "team": cmdTeam(s, g, p, a); break;
            case "zone": cmdZone(s, g, p, a); break;
            case "kit": cmdKit(s, g, p, a); break;
            case "spectate": case "camera": cmdSpectate(s, g, p, a); break;
            case "set": cmdSet(s, g, a); break;
            default: help(s);
        }
        return 1;
    }

    static void cmdTeam(CommandSourceStack s, Game g, ServerPlayer p, String[] a) {
        if (a.length < 2) { msg(s, "/event team create|delete|add|remove|spawn|flag|color|list"); return; }
        switch (a[1].toLowerCase()) {
            case "list":
                for (EvTeam t : g.st.teams.values()) msg(s, t.colored() + " §7- " + t.members.size() + " joueurs, respawn " + (t.respawn != null ? "ok" : "§cmanquant") + "§7, classes : " + t.classes);
                if (g.st.teams.isEmpty()) msg(s, "Aucune équipe.");
                break;
            case "create": {
                if (a.length < 3) { msg(s, "/event team create <nom> [couleur]"); break; }
                String r = Admin.teamCreate(a[2]);
                if (!Admin.isErr(r) && a.length > 3) {
                    ChatFormatting c = Opts.parseColor(a[3]);
                    if (c != null) Admin.teamColor(a[2], c);
                }
                reply(s, r);
                break;
            }
            case "delete": reply(s, a.length > 2 ? Admin.teamDelete(a[2]) : "!/event team delete <équipe>"); break;
            case "add": {
                if (a.length < 4) { msg(s, "/event team add <joueur> <équipe>"); break; }
                ServerPlayer o = g.server.getPlayerList().getPlayerByName(a[2]);
                if (o == null) { fail(s, "Joueur introuvable."); break; }
                reply(s, Admin.teamMember(o, a[3]));
                break;
            }
            case "remove": {
                ServerPlayer o = a.length > 2 ? g.server.getPlayerList().getPlayerByName(a[2]) : null;
                if (o == null) { fail(s, "Joueur introuvable."); break; }
                reply(s, Admin.teamMember(o, null));
                break;
            }
            case "spawn": case "flag": {
                if (p == null || a.length < 3) { fail(s, "Joueur en jeu et équipe valide requis."); break; }
                reply(s, a[1].equalsIgnoreCase("spawn") ? Admin.teamSpawn(a[2], p) : Admin.teamFlag(a[2], p, false));
                break;
            }
            case "color": {
                if (a.length < 4) { msg(s, "/event team color <équipe> <couleur>"); break; }
                reply(s, Admin.teamColor(a[2], Opts.parseColor(a[3])));
                break;
            }
            default: msg(s, "Sous-commande inconnue.");
        }
    }

    static void cmdZone(CommandSourceStack s, Game g, ServerPlayer p, String[] a) {
        if (a.length < 2) { msg(s, "/event zone create|delete|list|tp"); return; }
        switch (a[1].toLowerCase()) {
            case "list":
                for (EvZone z : g.st.zones.values()) msg(s, "§e" + z.name + " §7rayon " + z.radius + ", " + z.seconds + "s, " + (z.center == null ? "?" : z.center.pretty()));
                if (g.st.zones.isEmpty()) msg(s, "Aucune zone.");
                break;
            case "create": {
                if (p == null || a.length < 3) { msg(s, "/event zone create <nom> [rayon] [secondes] (en jeu)"); break; }
                double radius = 6; int seconds = 20;
                try {
                    if (a.length > 3) radius = Double.parseDouble(a[3]);
                    if (a.length > 4) seconds = Integer.parseInt(a[4]);
                } catch (NumberFormatException ex) { fail(s, "Nombre invalide."); break; }
                reply(s, Admin.zoneCreate(a[2], p, Math.max(1, radius), Math.max(1, seconds)));
                break;
            }
            case "delete": reply(s, a.length > 2 ? Admin.zoneDelete(a[2]) : "!/event zone delete <zone>"); break;
            case "tp": {
                if (p == null || a.length < 3) { fail(s, "Zone introuvable."); break; }
                reply(s, Admin.zoneTp(a[2], p));
                break;
            }
            default: msg(s, "Sous-commande inconnue.");
        }
    }

    static void cmdKit(CommandSourceStack s, Game g, ServerPlayer p, String[] a) {
        if (a.length < 2) { msg(s, "/event kit create|delete|edit|give"); return; }
        switch (a[1].toLowerCase()) {
            case "create": {
                if (a.length < 3) { msg(s, "/event kit create <nom>"); break; }
                reply(s, Admin.kitCreate(a[2], p));
                break;
            }
            case "delete": reply(s, a.length > 2 ? Admin.kitDelete(a[2]) : "!/event kit delete <kit>"); break;
            case "edit": {
                EvKit k = a.length > 2 ? g.st.kit(a[2]) : null;
                if (p == null || k == null) { fail(s, "Kit introuvable (ou joueur requis)."); break; }
                Net.openScreen(p, "kit:" + k.name);
                break;
            }
            case "give": {
                EvKit k = a.length > 2 ? g.st.kit(a[2]) : null;
                ServerPlayer o = a.length > 3 ? g.server.getPlayerList().getPlayerByName(a[3]) : p;
                if (k == null || o == null) { fail(s, "Kit ou joueur introuvable."); break; }
                Game.giveKit(o, k); msg(s, "Kit donné à " + o.getGameProfile().getName());
                break;
            }
            default: msg(s, "Sous-commande inconnue.");
        }
    }

    static void cmdSpectate(CommandSourceStack s, Game g, ServerPlayer p, String[] a) {
        if (p == null) { fail(s, "Joueur uniquement."); return; }
        UUID u = p.getUUID();
        if (a.length > 1) {
            ServerPlayer t = g.server.getPlayerList().getPlayerByName(a[1]);
            if (t == null) { fail(s, "Joueur introuvable."); return; }
            g.cameras.add(u); p.setGameMode(GameType.SPECTATOR); p.setCamera(t);
            msg(s, "Tu suis " + t.getGameProfile().getName() + ". §7(/event spectate pour quitter)");
            return;
        }
        if (g.cameras.remove(u)) { p.setCamera(p); p.setGameMode(GameType.SURVIVAL); msg(s, "Mode caméra désactivé."); }
        else { g.cameras.add(u); p.setGameMode(GameType.SPECTATOR); msg(s, "Mode caméra activé : exclu des équipes. §7/event spectate <joueur> pour suivre quelqu'un."); }
    }

    static void cmdSet(CommandSourceStack s, Game g, String[] a) {
        List<String> keys = new ArrayList<>();
        for (Opts.Opt o : Opts.ALL) keys.add(o.key);
        if (a.length < 3) { msg(s, "Options : " + String.join(", ", keys)); return; }
        Opts.Opt o = Opts.get(a[1]);
        if (o == null) { fail(s, "Option inconnue. Options : " + String.join(", ", keys)); return; }
        int v;
        if (o.bool()) v = Boolean.parseBoolean(a[2]) || a[2].equals("1") ? 1 : 0;
        else {
            try { v = Integer.parseInt(a[2]); } catch (NumberFormatException ex) { fail(s, "Nombre entier attendu."); return; }
        }
        reply(s, Admin.setting(a[1], v));
        msg(s, a[1] + " = " + a[2]);
    }

    // ------------------------------------------------------------------ completion
    static CompletableFuture<Suggestions> suggest(Collection<String> options, SuggestionsBuilder b, String... extra) {
        String last = b.getRemaining().toLowerCase();
        for (String o : options) if (o.toLowerCase().startsWith(last)) b.suggest(o);
        for (String o : extra) if (o.toLowerCase().startsWith(last)) b.suggest(o);
        return b.buildFuture();
    }

    static CompletableFuture<Suggestions> suggestEvent(CommandContext<CommandSourceStack> c, SuggestionsBuilder b) {
        Game g = Game.I;
        String rem = b.getRemaining();
        String[] a = rem.split(" ", -1);
        String last = a[a.length - 1].toLowerCase();
        List<String> out = new ArrayList<>();
        if (a.length == 1) out.addAll(Arrays.asList("gui", "start", "go", "stop", "team", "zone", "kit", "spectate", "set", "preset"));
        else if (g != null) {
            String m = a[0].toLowerCase();
            if (a.length == 2) {
                if (m.equals("team")) out.addAll(Arrays.asList("create", "delete", "add", "remove", "spawn", "flag", "color", "list"));
                else if (m.equals("zone")) out.addAll(Arrays.asList("create", "delete", "list", "tp"));
                else if (m.equals("kit")) out.addAll(Arrays.asList("create", "delete", "edit", "give"));
                else if (m.equals("set")) for (Opts.Opt o : Opts.ALL) out.add(o.key);
                else if (m.equals("spectate")) out.addAll(onlineNames());
            } else if (a.length == 3) {
                String s2 = a[1].toLowerCase();
                if (m.equals("team") && !s2.equals("create") && !s2.equals("add") && !s2.equals("remove")) out.addAll(g.st.teams.keySet());
                else if (m.equals("team")) { if (!s2.equals("create")) out.addAll(onlineNames()); }
                else if (m.equals("zone")) out.addAll(g.st.zones.keySet());
                else if (m.equals("kit")) out.addAll(g.st.kits.keySet());
            } else if (a.length == 4) {
                if (m.equals("team") && a[1].equalsIgnoreCase("add")) out.addAll(g.st.teams.keySet());
                else if (m.equals("team") && (a[1].equalsIgnoreCase("create") || a[1].equalsIgnoreCase("color"))) for (ChatFormatting f : Opts.PALETTE) out.add(f.getName());
                else if (m.equals("kit") && a[1].equalsIgnoreCase("give")) out.addAll(onlineNames());
            }
        }
        SuggestionsBuilder sb = b.createOffset(b.getStart() + rem.length() - a[a.length - 1].length());
        for (String o : out) if (o.toLowerCase().startsWith(last)) sb.suggest(o);
        return sb.buildFuture();
    }
}
