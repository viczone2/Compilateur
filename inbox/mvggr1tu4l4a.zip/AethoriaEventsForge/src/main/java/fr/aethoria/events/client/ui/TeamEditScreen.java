package fr.aethoria.events.client.ui;

import fr.aethoria.events.Opts;
import fr.aethoria.events.client.ClientState;
import fr.aethoria.events.client.ClientState.Act;
import fr.aethoria.events.client.ClientState.CKit;
import fr.aethoria.events.client.ClientState.CPlayer;
import fr.aethoria.events.client.ClientState.CTeam;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;

public final class TeamEditScreen extends BaseScreen {
    private String name;
    private int tab;

    public TeamEditScreen(Screen back, String name) { super("Équipe", back); this.name = name; }

    @Override protected String subtitle() { CTeam t = ClientState.team(name); return t == null ? "" : t.color + t.name; }

    @Override
    protected void build() {
        CTeam t = ClientState.team(name);
        if (t == null) { label(cx() + 6, cy() + 8, "Équipe introuvable.", UI.MUTED); return; }
        tabs(cx(), cy(), cw(), new String[]{"Général", "Classes", "Membres"}, () -> tab, i -> tab = i);
        int y0 = cy() + 28;
        if (tab == 0) {
            label(cx(), y0 + 2, "Couleur", UI.MUTED);
            for (int i = 0; i < Opts.PALETTE.length; i++) {
                ChatFormatting c = Opts.PALETTE[i];
                addRenderableWidget(new Swatch(cx() + 3 + i * 29, y0 + 16, 24, 18, Opts.rgb(c), c == t.color, () -> Act.of("team.color").s("name", name).s("color", c.getName()).send()));
            }
            btn(cx(), y0 + 44, cw(), 22, "Renommer l'équipe", UiButton.Style.NORMAL, () ->
                    minecraft.setScreen(new PromptScreen("Renommer l'équipe", "Nouveau nom", t.name, this, n -> { Act.of("team.rename").s("name", name).s("new", n).send(); name = n; })));
            label(cx(), y0 + 76, "Point de réapparition", UI.TEXT);
            label(cx(), y0 + 87, t.respawn.isEmpty() ? "Non défini" : t.respawn, t.respawn.isEmpty() ? UI.BAD : UI.MUTED);
            btn(cx() + cw() - 110, y0 + 76, 110, 20, "Définir ici", UiButton.Style.SUCCESS, () -> Act.of("team.spawn").s("name", name).send());
            label(cx(), y0 + 110, "Drapeau (mode capture)", UI.TEXT);
            label(cx(), y0 + 121, t.flag.isEmpty() ? "Aucun" : t.flag, UI.MUTED);
            btn(cx() + cw() - 110, y0 + 110, 110, 20, "Définir ici", UiButton.Style.SUCCESS, () -> Act.of("team.flag").s("name", name).send());
            if (!t.flag.isEmpty()) btn(cx() + cw() - 190, y0 + 110, 76, 20, "Retirer", UiButton.Style.NORMAL, () -> Act.of("team.flag.clear").s("name", name).send());
            btn(cx(), y0 + 150, cw(), 20, "Supprimer l'équipe", UiButton.Style.DANGER, () -> { Act.of("team.delete").s("name", name).send(); minecraft.setScreen(back); }).confirm();
        } else if (tab == 1) {
            ScrollList l = list(cx(), y0, cw(), ch() - 28);
            for (CKit k : ClientState.kits) {
                boolean on = t.classes.contains(k.name);
                l.rows.add(new CardRow().icon(k.icon()).title(k.name).line(k.items.size() + " objet(s)" + (k.medic ? " · Médecin" : ""))
                        .toggle(on).onClick(() -> Act.of("team.class").s("name", name).s("kit", k.name).send()));
            }
            if (ClientState.kits.isEmpty()) label(cx() + 6, y0 + 8, "Aucun kit : crée-en dans « Kits et classes ».", UI.MUTED);
        } else {
            ScrollList l = list(cx(), y0, cw(), ch() - 28);
            for (CPlayer p : ClientState.players) {
                boolean in = p.team.equalsIgnoreCase(t.name);
                CTeam other = p.team.isEmpty() ? null : ClientState.team(p.team);
                l.rows.add(new CardRow().icon(new net.minecraft.world.item.ItemStack(net.minecraft.world.item.Items.PLAYER_HEAD)).title(p.name)
                        .line(other == null ? "Sans équipe" : "Équipe : " + other.color + other.name).toggle(in)
                        .onClick(() -> Act.of("team.member").s("uuid", p.uuid).s("team", in ? "" : t.name).send()));
            }
        }
    }

    @Override
    protected void renderContent(GuiGraphics g, int mx, int my, float pt) { }
}
