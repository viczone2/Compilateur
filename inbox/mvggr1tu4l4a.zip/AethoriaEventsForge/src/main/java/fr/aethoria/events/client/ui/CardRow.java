package fr.aethoria.events.client.ui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import java.util.ArrayList;
import java.util.List;

/** Ligne "carte" : icone, titre, lignes de detail, pastille ou interrupteur a droite. */
public class CardRow implements ScrollList.Row {
    private ItemStack icon = ItemStack.EMPTY;
    private int accent;
    private String title = "";
    private final List<String> lines = new ArrayList<>();
    private String badge = "";
    private int badgeColor = UI.MUTED;
    private Boolean toggle;
    private Runnable onClick;
    private List<Component> tip;

    public CardRow icon(ItemStack s) { icon = s; return this; }
    public CardRow accent(int c) { accent = c; return this; }
    public CardRow title(String t) { title = t; return this; }
    public CardRow line(String l) { lines.add(l); return this; }
    public CardRow badge(String b, int color) { badge = b; badgeColor = color; return this; }
    public CardRow toggle(boolean on) { toggle = on; return this; }
    public CardRow onClick(Runnable r) { onClick = r; return this; }
    public CardRow tip(List<String> l) { tip = new ArrayList<>(); for (String s : l) tip.add(Component.literal(s)); return this; }

    @Override public int height() { return Math.max(30, 14 + 10 + lines.size() * 10); }

    @Override
    public void render(GuiGraphics g, int x, int y, int w, int mx, int my, boolean hover) {
        int h = height();
        UI.fillRound(g, x, y, w, h, 4, hover && onClick != null ? UI.CARD_HI : UI.CARD);
        if (accent != 0) UI.fillRound(g, x, y + 3, 3, h - 6, 1, accent);
        int tx = x + 12;
        if (!icon.isEmpty()) { UI.drawItem(g, icon, x + 9, y + (h - 16) / 2, 1f); tx = x + 32; }
        int rightPad = toggle != null ? 36 : (badge.isEmpty() ? 8 : UI.font().width(badge) + 16);
        UI.text(g, UI.fit(title, w - (tx - x) - rightPad), tx, y + 6, UI.TEXT);
        for (int i = 0; i < lines.size(); i++) UI.text(g, UI.fit(lines.get(i), w - (tx - x) - rightPad), tx, y + 18 + i * 10, UI.MUTED);
        if (toggle != null) UI.drawSwitch(g, x + w - 32, y + (h - 12) / 2, toggle);
        else if (!badge.isEmpty()) UI.textR(g, badge, x + w - 8, y + (h - 8) / 2, badgeColor);
    }

    @Override
    public boolean click(int rx, int ry, int w, int button) {
        if (onClick == null || button != 0) return false;
        UI.click();
        onClick.run();
        return true;
    }

    @Override
    public List<Component> tooltip(int rx, int ry, int w) { return tip; }
}
