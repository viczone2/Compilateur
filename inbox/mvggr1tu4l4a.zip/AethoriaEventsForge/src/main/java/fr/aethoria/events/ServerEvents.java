package fr.aethoria.events;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import java.util.UUID;

/** Evenements Forge cote serveur. */
@Mod.EventBusSubscriber(modid = AethoriaEvents.MODID)
public final class ServerEvents {
    private ServerEvents() {}

    @SubscribeEvent
    public static void onStarting(ServerStartingEvent e) { Game.I = new Game(e.getServer()); }

    @SubscribeEvent
    public static void onStopping(ServerStoppingEvent e) {
        if (Game.I != null) { Game.I.shutdown(); Game.I = null; }
    }

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) { Cmds.register(e.getDispatcher()); }

    @SubscribeEvent
    public static void onTick(TickEvent.ServerTickEvent e) {
        if (e.phase == TickEvent.Phase.END && Game.I != null) Game.I.serverTick();
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (Game.I != null && e.getEntity() instanceof ServerPlayer) Game.I.onJoin((ServerPlayer) e.getEntity());
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (Game.I != null && e.getEntity() instanceof ServerPlayer) Game.I.onQuit((ServerPlayer) e.getEntity());
    }

    // ------------------------------------------------------------------ degats
    private static ServerPlayer attacker(DamageSource src) {
        Entity en = src.getEntity();
        if (en instanceof ServerPlayer) return (ServerPlayer) en;
        if (en instanceof Projectile && ((Projectile) en).getOwner() instanceof ServerPlayer) return (ServerPlayer) ((Projectile) en).getOwner();
        return null;
    }

    /** Invincibilite (deploiement, protection, a terre, reapparition) et joueurs a terre qui ne peuvent pas frapper. */
    @SubscribeEvent
    public static void onAttack(LivingAttackEvent e) {
        Game g = Game.I;
        if (g == null || !g.running) return;
        ServerPlayer by = attacker(e.getSource());
        if (by != null && g.downed.containsKey(by.getUUID())) { e.setCanceled(true); return; }
        if (!(e.getEntity() instanceof ServerPlayer)) return;
        ServerPlayer p = (ServerPlayer) e.getEntity();
        UUID u = p.getUUID();
        if (g.teamOf(u) == null) return;
        if (g.deploying()) { e.setCanceled(true); return; }
        Long until = g.prot.get(u);
        if (until != null) {
            if (System.currentTimeMillis() < until) { e.setCanceled(true); return; }
            g.prot.remove(u);
        }
        if (g.downed.containsKey(u) || g.respawnAt.containsKey(u)) e.setCanceled(true);
    }

    /** Un coup mortel met le joueur a terre (ou l'elimine) au lieu de le tuer. */
    @SubscribeEvent
    public static void onDamage(LivingDamageEvent e) {
        Game g = Game.I;
        if (g == null || !g.running || !(e.getEntity() instanceof ServerPlayer)) return;
        ServerPlayer p = (ServerPlayer) e.getEntity();
        if (g.teamOf(p.getUUID()) == null || !g.alive(p)) return;
        if (p.getHealth() + p.getAbsorptionAmount() - e.getAmount() > 0) return;
        e.setCanceled(true);
        ServerPlayer by = attacker(e.getSource());
        boolean bypass = e.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY);
        if (g.flag("revive") && !bypass) g.down(p, by); else g.eliminate(p, by);
    }

    /** Filet de securite : aucune vraie mort pendant l'evenement. */
    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        Game g = Game.I;
        if (g == null || !g.running || !(e.getEntity() instanceof ServerPlayer)) return;
        ServerPlayer p = (ServerPlayer) e.getEntity();
        if (g.teamOf(p.getUUID()) == null) return;
        e.setCanceled(true);
        g.eliminate(p, attacker(e.getSource()));
    }

    // ------------------------------------------------------------------ joueurs a terre : plus d'interactions
    private static boolean isDown(net.minecraft.world.entity.player.Player p) {
        return Game.I != null && Game.I.running && Game.I.downed.containsKey(p.getUUID());
    }

    @SubscribeEvent
    public static void onUse(PlayerInteractEvent.RightClickItem e) { if (isDown(e.getEntity())) e.setCanceled(true); }

    @SubscribeEvent
    public static void onUseBlock(PlayerInteractEvent.RightClickBlock e) { if (isDown(e.getEntity())) e.setCanceled(true); }

    @SubscribeEvent
    public static void onBreak(PlayerInteractEvent.LeftClickBlock e) { if (isDown(e.getEntity())) e.setCanceled(true); }
}
