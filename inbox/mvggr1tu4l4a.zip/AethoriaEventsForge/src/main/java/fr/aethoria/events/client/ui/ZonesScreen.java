package fr.aethoria.events.client.ui;

import fr.aethoria.events.client.ClientState;
import fr.aethoria.events.client.ClientState.Act;
import fr.aethoria.events.client.ClientState.CZone;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public final class ZonesScreen extends BaseScreen {
    public ZonesScreen(Screen back) { super("Zones de capture", back); }

    @Override protected String subtitle() { return ClientState.zones.size() + " zone(s)"; }

    static String typeName(String t) { return t.equals("HQ") ? "QG" : t.equals("DEPOT") ? "Dépôt" : "Normale"; }

    @Override
    protected void build() {
        ScrollList l = list(cx(), cy(), cw(), ch() - 28);
        for (CZone z : ClientState.zones) {
            ItemStack icon = new ItemStack(z.type.equals("HQ") ? Items.NETHER_STAR : z.type.equals("DEPOT") ? Items.CHEST : Items.BEACON);
            l.rows.add(new CardRow().icon(icon).accent(z.type.equals("HQ") ? UI.BAD : z.type.equals("DEPOT") ? UI.WARN : UI.GOOD)
                    .title(z.name + " §7[" + typeName(z.type) + "]")
                    .line("Rayon " + (int) z.radius + " · capture " + z.seconds + "s")
                    .line(z.center)
                    .badge("Modifier ›", UI.MUTED)
                    .onClick(() -> minecraft.setScreen(new ZoneEditScreen(this, z.name))));
        }
        if (ClientState.zones.isEmpty()) label(cx() + 6, cy() + 8, "Aucune zone. Place-toi à l'endroit voulu puis crée-la.", UI.MUTED);
        btn(cx(), cy() + ch() - 22, cw(), 20, "+ Nouvelle zone (à ma position)", UiButton.Style.PRIMARY, () ->
                minecraft.setScreen(new PromptScreen("Nouvelle zone", "Nom de la zone", "", this, n -> Act.of("zone.create").s("name", n).send())));
    }
}
