package fr.aethoria.events;

import com.google.gson.*;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.TagParser;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.fml.loading.FMLPaths;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Donnees de configuration : equipes, kits, zones, reglages. Sauvegardees dans config/aethoriaevents/data.json. */
public final class Store {
    final Map<String, EvTeam> teams = new LinkedHashMap<>();
    final Map<String, EvKit> kits = new LinkedHashMap<>();
    final Map<String, EvZone> zones = new LinkedHashMap<>();
    final Map<String, Integer> settings = new LinkedHashMap<>();
    private final Path dir = FMLPaths.CONFIGDIR.get().resolve("aethoriaevents");
    private final Path file = dir.resolve("data.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    Store() { for (Opts.Opt o : Opts.ALL) settings.put(o.key, o.def); }

    int get(String k) { return settings.getOrDefault(k, 0); }
    boolean bool(String k) { return get(k) != 0; }

    EvTeam team(String n) {
        if (n == null) return null;
        for (EvTeam t : teams.values()) if (t.name.equalsIgnoreCase(n)) return t;
        return null;
    }

    EvKit kit(String n) {
        if (n == null) return null;
        for (EvKit k : kits.values()) if (k.name.equalsIgnoreCase(n)) return k;
        return null;
    }

    EvZone zone(String n) {
        if (n == null) return null;
        for (EvZone z : zones.values()) if (z.name.equalsIgnoreCase(n)) return z;
        return null;
    }

    static String itemToStr(ItemStack s) { return s.save(new CompoundTag()).toString(); }

    static ItemStack strToItem(String str) {
        try { return ItemStack.of(TagParser.parseTag(str)); } catch (Exception e) { return ItemStack.EMPTY; }
    }

    synchronized void save() {
        try {
            Files.createDirectories(dir);
            JsonObject root = new JsonObject();
            JsonObject set = new JsonObject();
            for (Map.Entry<String, Integer> e : settings.entrySet()) set.addProperty(e.getKey(), e.getValue());
            root.add("settings", set);
            JsonArray ta = new JsonArray();
            for (EvTeam t : teams.values()) {
                JsonObject o = new JsonObject();
                o.addProperty("name", t.name); o.addProperty("color", t.color.getName());
                if (t.respawn != null) o.add("respawn", t.respawn.toJson());
                if (t.flag != null) o.add("flag", t.flag.toJson());
                JsonArray cl = new JsonArray(); for (String c : t.classes) cl.add(c); o.add("classes", cl);
                ta.add(o);
            }
            root.add("teams", ta);
            JsonArray ka = new JsonArray();
            for (EvKit k : kits.values()) {
                JsonObject o = new JsonObject();
                o.addProperty("name", k.name); o.addProperty("limit", k.limit); o.addProperty("medic", k.medic);
                JsonArray it = new JsonArray(); for (ItemStack s : k.items) it.add(itemToStr(s)); o.add("items", it);
                ka.add(o);
            }
            root.add("kits", ka);
            JsonArray za = new JsonArray();
            for (EvZone z : zones.values()) {
                JsonObject o = new JsonObject();
                o.addProperty("name", z.name); o.add("center", z.center.toJson());
                o.addProperty("radius", z.radius); o.addProperty("seconds", z.seconds); o.addProperty("type", z.type);
                if (z.hq != null) o.addProperty("hq", z.hq);
                za.add(o);
            }
            root.add("zones", za);
            Path tmp = dir.resolve("data.json.tmp");
            Files.write(tmp, GSON.toJson(root).getBytes(StandardCharsets.UTF_8));
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
        } catch (Exception ex) {
            AethoriaEvents.LOG.warn("data.json: {}", ex.toString());
        }
    }

    void load() {
        if (!Files.exists(file)) return;
        try {
            JsonObject root = JsonParser.parseString(new String(Files.readAllBytes(file), StandardCharsets.UTF_8)).getAsJsonObject();
            if (root.has("settings")) for (Map.Entry<String, JsonElement> e : root.getAsJsonObject("settings").entrySet())
                if (Opts.get(e.getKey()) != null) settings.put(e.getKey(), e.getValue().getAsInt());
            if (root.has("teams")) for (JsonElement el : root.getAsJsonArray("teams")) {
                JsonObject o = el.getAsJsonObject();
                EvTeam t = new EvTeam(o.get("name").getAsString());
                ChatFormatting c = Opts.parseColor(o.has("color") ? o.get("color").getAsString() : null);
                if (c != null) t.color = c;
                if (o.has("respawn")) t.respawn = Loc.fromJson(o.getAsJsonObject("respawn"));
                if (o.has("flag")) t.flag = Loc.fromJson(o.getAsJsonObject("flag"));
                if (o.has("classes")) for (JsonElement c2 : o.getAsJsonArray("classes")) t.classes.add(c2.getAsString());
                teams.put(t.name, t);
            }
            if (root.has("kits")) for (JsonElement el : root.getAsJsonArray("kits")) {
                JsonObject o = el.getAsJsonObject();
                EvKit k = new EvKit(o.get("name").getAsString());
                k.limit = o.has("limit") ? o.get("limit").getAsInt() : 0;
                k.medic = o.has("medic") && o.get("medic").getAsBoolean();
                if (o.has("items")) for (JsonElement i : o.getAsJsonArray("items")) {
                    ItemStack s = strToItem(i.getAsString());
                    if (!s.isEmpty()) k.items.add(s);
                }
                kits.put(k.name, k);
            }
            if (root.has("zones")) for (JsonElement el : root.getAsJsonArray("zones")) {
                JsonObject o = el.getAsJsonObject();
                EvZone z = new EvZone(o.get("name").getAsString());
                z.center = Loc.fromJson(o.getAsJsonObject("center"));
                z.radius = o.has("radius") ? o.get("radius").getAsDouble() : 6;
                z.seconds = o.has("seconds") ? o.get("seconds").getAsInt() : 20;
                z.type = o.has("type") ? o.get("type").getAsString() : "NORMAL";
                z.hq = o.has("hq") ? o.get("hq").getAsString() : null;
                if (z.center != null) zones.put(z.name, z);
            }
        } catch (Exception ex) {
            AethoriaEvents.LOG.error("Impossible de lire data.json : {}", ex.toString());
        }
    }
}
