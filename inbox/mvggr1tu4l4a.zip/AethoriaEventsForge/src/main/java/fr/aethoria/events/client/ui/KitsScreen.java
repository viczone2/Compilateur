package fr.aethoria.events.client.ui;

import fr.aethoria.events.client.ClientState;
import fr.aethoria.events.client.ClientState.Act;
import fr.aethoria.events.client.ClientState.CKit;
import net.minecraft.client.gui.screens.Screen;

public final class KitsScreen extends BaseScreen {
    public KitsScreen(Screen back) { super("Kits et classes", back); }

    @Override protected String subtitle() { return ClientState.kits.size() + " kit(s)"; }

    @Override
    protected void build() {
        ScrollList l = list(cx(), cy(), cw(), ch() - 28);
        for (CKit k : ClientState.kits) {
            l.rows.add(new CardRow().icon(k.icon()).accent(k.medic ? UI.GOOD : UI.GOLD_DK).title(k.name)
                    .line(k.items.size() + " objet(s) · limite " + (k.limit == 0 ? "défaut" : String.valueOf(k.limit)))
                    .line(k.medic ? "§aMédecin : relève les joueurs à terre" : "§7Classe standard")
                    .badge("Modifier ›", UI.MUTED)
                    .onClick(() -> minecraft.setScreen(new KitEditScreen(this, k.name))));
        }
        if (ClientState.kits.isEmpty()) label(cx() + 6, cy() + 8, "Aucun kit. Crée-en un ci-dessous.", UI.MUTED);
        int half = (cw() - 4) / 2, y = cy() + ch() - 22;
        btn(cx(), y, half, 20, "+ Kit vide", UiButton.Style.PRIMARY, () ->
                minecraft.setScreen(new PromptScreen("Nouveau kit", "Nom du kit", "", this, n -> Act.of("kit.create").s("name", n).send())));
        btn(cx() + half + 4, y, half, 20, "+ Depuis mon inventaire", UiButton.Style.PRIMARY, () ->
                minecraft.setScreen(new PromptScreen("Kit depuis l'inventaire", "Nom du kit", "", this, n -> Act.of("kit.create").s("name", n).b("fromInv", true).send())));
    }
}
