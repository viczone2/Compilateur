package fr.aethoria.events.net;

import fr.aethoria.events.client.ClientHooks;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

public class S2CHud {
    private final CompoundTag tag; // null = effacer

    public S2CHud(CompoundTag tag) { this.tag = tag; }

    public void encode(FriendlyByteBuf buf) {
        buf.writeBoolean(tag != null);
        if (tag != null) buf.writeNbt(tag);
    }

    public static S2CHud decode(FriendlyByteBuf buf) {
        return new S2CHud(buf.readBoolean() ? buf.readNbt() : null);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.hud(tag)));
        c.setPacketHandled(true);
    }
}
