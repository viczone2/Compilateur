package fr.aethoria.events.client.ui;

import fr.aethoria.events.Opts;
import fr.aethoria.events.client.ClientState;
import fr.aethoria.events.client.ClientState.Act;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.List;

/** Reglages de la partie, regroupes par categorie. */
public final class SettingsScreen extends BaseScreen {
    public SettingsScreen(Screen back) { super("Réglages", back); }

    @Override protected String subtitle() { return "Clic sur un interrupteur ou sur − / + (Maj = ×5)"; }

    @Override
    protected void build() {
        ScrollList l = list(cx(), cy(), cw(), ch());
        String group = "";
        for (Opts.Opt o : Opts.ALL) {
            if (!o.group.equals(group)) {
                group = o.group;
                final String gname = group;
                l.rows.add(new ScrollList.Row() {
                    @Override public int height() { return 16; }
                    @Override public void render(GuiGraphics g, int x, int y, int w, int mx, int my, boolean hover) {
                        UI.text(g, "§l" + gname, x + 4, y + 4, UI.GOLD);
                        g.fill(x + UI.font().width(gname) + 14, y + 8, x + w, y + 9, UI.LINE);
                    }
                });
            }
            l.rows.add(new SettingRow(o));
        }
    }

    private static final class SettingRow implements ScrollList.Row {
        final Opts.Opt o;
        SettingRow(Opts.Opt o) { this.o = o; }
        @Override public int height() { return 26; }

        int value() { return ClientState.setting(o.key); }

        @Override
        public void render(GuiGraphics g, int x, int y, int w, int mx, int my, boolean hover) {
            UI.fillRound(g, x, y, w, 26, 4, hover ? UI.CARD_HI : UI.CARD);
            UI.drawItem(g, UI.icon(o.icon), x + 6, y + 5, 1f);
            int right = o.bool() ? 40 : 112;
            UI.text(g, UI.fit(o.label, w - 30 - right), x + 28, y + 9, UI.TEXT);
            if (o.bool()) UI.drawSwitch(g, x + w - 32, y + 7, value() != 0);
            else {
                int mxp = x + w - 108;
                boolean hm = UI.in(mx, my, mxp, y + 4, 20, 18), hp = UI.in(mx, my, x + w - 28, y + 4, 20, 18);
                UI.fillRound(g, mxp, y + 4, 20, 18, 3, hm ? UI.GOLD_DK : 0xFF2F374B);
                UI.fillRound(g, x + w - 28, y + 4, 20, 18, 3, hp ? UI.GOLD_DK : 0xFF2F374B);
                UI.textC(g, "-", mxp + 10, y + 9, UI.TEXT);
                UI.textC(g, "+", x + w - 18, y + 9, UI.TEXT);
                UI.textC(g, String.valueOf(value()), x + w - 68, y + 9, UI.GOLD);
            }
        }

        @Override
        public boolean click(int rx, int ry, int w, int button) {
            int v = value();
            if (o.bool()) { send(v != 0 ? 0 : 1); return true; }
            int step = o.step * (net.minecraft.client.gui.screens.Screen.hasShiftDown() ? 5 : 1);
            if (rx >= w - 108 && rx < w - 88) { send(Math.max(o.min, v - step)); return true; }
            if (rx >= w - 28 && rx < w - 8) { send(v + step); return true; }
            return false;
        }

        void send(int nv) { UI.click(); Act.of("setting").s("key", o.key).n("value", nv).send(); }

        @Override
        public List<Component> tooltip(int rx, int ry, int w) { return null; }
    }
}
