package fr.aethoria.events.client.ui;

import fr.aethoria.events.client.ClientState;
import fr.aethoria.events.client.ClientState.Act;
import fr.aethoria.events.client.ClientState.CTeam;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;

/** Tableau de bord : etat de la partie, acces aux equipes / kits / zones / reglages, lancement. */
public final class MainScreen extends BaseScreen {
    public MainScreen(Screen back) { super("Gestion de l'événement", back); }

    @Override protected int panelH() { return 292; }

    @Override
    protected void build() {
        int w = (cw() - 6) / 2, y = py + 86;
        btn(cx(), y, w, 42, "Équipes", UiButton.Style.NORMAL, () -> minecraft.setScreen(new TeamsScreen(this)))
                .icon(new ItemStack(Items.WHITE_BANNER)).sub(ClientState.teams.size() + " équipe(s)");
        btn(cx() + w + 6, y, w, 42, "Kits et classes", UiButton.Style.NORMAL, () -> minecraft.setScreen(new KitsScreen(this)))
                .icon(new ItemStack(Items.CHEST)).sub(ClientState.kits.size() + " kit(s)");
        btn(cx(), y + 48, w, 42, "Zones", UiButton.Style.NORMAL, () -> minecraft.setScreen(new ZonesScreen(this)))
                .icon(new ItemStack(Items.BEACON)).sub(ClientState.zones.size() + " zone(s)");
        btn(cx() + w + 6, y + 48, w, 42, "Réglages", UiButton.Style.NORMAL, () -> minecraft.setScreen(new SettingsScreen(this)))
                .icon(new ItemStack(Items.COMPARATOR)).sub("Durée, points, règles");
        int ay = y + 100;
        if (!ClientState.running) {
            btn(cx(), ay, cw(), 24, "LANCER L'ÉVÉNEMENT", UiButton.Style.SUCCESS, () -> Act.of("game.start").send());
            btn(cx(), ay + 28, cw(), 20, "Préréglage « Opération Reconquête »", UiButton.Style.NORMAL, () -> Act.of("game.preset").send())
                    .confirm().tip("Crée 5 classes, 2 équipes et applique les réglages.", "Ne supprime rien d'existant.");
        } else {
            if (ClientState.deploying) {
                int half = (cw() - 4) / 2;
                btn(cx(), ay, half, 24, "Lancer le combat", UiButton.Style.PRIMARY, () -> Act.of("game.go").send());
                btn(cx() + half + 4, ay, half, 24, "ARRÊTER", UiButton.Style.DANGER, () -> Act.of("game.stop").send()).confirm();
            } else btn(cx(), ay, cw(), 24, "ARRÊTER L'ÉVÉNEMENT", UiButton.Style.DANGER, () -> Act.of("game.stop").send()).confirm();
        }
    }

    @Override
    protected void renderContent(GuiGraphics g, int mx, int my, float pt) {
        int x = cx(), y = py + 40, w = cw();
        UI.fillRound(g, x, y, w, 40, 5, UI.CARD);
        int col = !ClientState.running ? UI.MUTED : ClientState.deploying ? UI.WARN : UI.GOOD;
        UI.fillRound(g, x + 8, y + 8, 8, 8, 4, col);
        String st = !ClientState.running ? "Aucun événement en cours"
                : ClientState.deploying ? "Déploiement - " + UI.mmss(ClientState.remainingMs())
                : "Combat - " + UI.mmss(ClientState.remainingMs()) + " restantes";
        UI.text(g, st, x + 22, y + 8, UI.TEXT);
        if (ClientState.running) {
            int cxp = x + 10;
            for (CTeam t : ClientState.teams) {
                String s = t.name + " " + t.points;
                int tw = UI.font().width(s);
                UI.fillRound(g, cxp, y + 24, 8, 8, 2, t.rgb());
                UI.text(g, s, cxp + 12, y + 24, UI.TEXT);
                cxp += tw + 26;
            }
        } else UI.text(g, ClientState.teams.size() + " équipes · " + ClientState.zones.size() + " zones · " + ClientState.kits.size() + " kits", x + 10, y + 24, UI.MUTED);
    }
}
