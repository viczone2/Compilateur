package fr.aethoria.events.client.ui;

import fr.aethoria.events.client.ClientState;
import fr.aethoria.events.client.ClientState.Act;
import fr.aethoria.events.client.ClientState.CKit;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Edition d'un kit : grille d'objets cliquable, catalogue, copie d'inventaire, limite, role de medecin. */
public final class KitEditScreen extends BaseScreen {
    private static final int COLS = 9, CELL = 20, ROWS = 5;
    private String name;

    public KitEditScreen(Screen back, String name) { super("Kit", back); this.name = name; }

    @Override protected int panelH() { return 304; }
    @Override protected String subtitle() { return name; }

    private int gx() { return cx(); }
    private int gy() { return cy() + 4; }

    @Override
    protected void build() {
        CKit k = ClientState.kit(name);
        if (k == null) { label(cx() + 6, cy() + 8, "Kit introuvable.", UI.MUTED); return; }
        int rx = cx() + 196, rw = cw() - 196, y = cy() + 4;
        btn(rx, y, rw, 20, "Catalogue des objets", UiButton.Style.PRIMARY, () -> minecraft.setScreen(new CatalogScreen(this, name))).icon(new ItemStack(Items.COMPASS));
        btn(rx, y + 24, rw, 20, "Ajouter l'objet en main", UiButton.Style.NORMAL, () -> Act.of("kit.addhand").s("name", name).send());
        btn(rx, y + 48, rw, 20, "Copier mon inventaire", UiButton.Style.NORMAL, () -> Act.of("kit.copyinv").s("name", name).send()).confirm()
                .tip("Remplace le contenu du kit par ton inventaire", "(armure et main secondaire comprises).");
        btn(rx, y + 72, rw, 20, "Vider le kit", UiButton.Style.DANGER, () -> Act.of("kit.clear").s("name", name).send()).confirm();
        btn(rx, y + 96, rw, 20, "Tester sur moi", UiButton.Style.SUCCESS, () -> Act.of("kit.give").s("name", name).send())
                .tip("Équipe ce kit (remplace ton inventaire).");
        btn(rx, y + 128, rw, 20, "Renommer", UiButton.Style.NORMAL, () ->
                minecraft.setScreen(new PromptScreen("Renommer le kit", "Nouveau nom", k.name, this, n -> { Act.of("kit.rename").s("name", name).s("new", n).send(); name = n; })));
        btn(rx, y + 152, rw, 20, "Supprimer le kit", UiButton.Style.DANGER, () -> { Act.of("kit.delete").s("name", name).send(); minecraft.setScreen(back); }).confirm();

        int ly = gy() + ROWS * CELL + 22;
        label(cx(), ly + 6, "Limite par équipe", UI.TEXT);
        btn(cx() + 100, ly, 22, 20, "-", UiButton.Style.NORMAL, () -> Act.of("kit.limit").s("name", name).n("delta", -1).send());
        labelC(cx() + 140, ly + 6, k.limit == 0 ? "défaut" : String.valueOf(k.limit), UI.GOLD);
        btn(cx() + 158, ly, 22, 20, "+", UiButton.Style.NORMAL, () -> Act.of("kit.limit").s("name", name).n("delta", 1).send());
        btn(cx(), ly + 26, 180, 20, k.medic ? "Médecin : OUI (relève les joueurs)" : "Médecin : non", k.medic ? UiButton.Style.SUCCESS : UiButton.Style.NORMAL,
                () -> Act.of("kit.medic").s("name", name).send());
    }

    @Override
    protected void renderContent(GuiGraphics g, int mx, int my, float pt) {
        CKit k = ClientState.kit(name);
        if (k == null) return;
        for (int i = 0; i < COLS * ROWS; i++) {
            int x = gx() + (i % COLS) * CELL, y = gy() + (i / COLS) * CELL;
            boolean hov = UI.in(mx, my, x, y, CELL - 2, CELL - 2);
            UI.fillRound(g, x, y, CELL - 2, CELL - 2, 3, hov && i < k.items.size() ? UI.CARD_HI : UI.CARD);
            if (i < k.items.size()) {
                g.renderItem(k.items.get(i), x + 1, y + 1);
                g.renderItemDecorations(font, k.items.get(i), x + 1, y + 1);
            }
        }
        UI.text(g, k.items.size() + "/45 objets", gx(), gy() + ROWS * CELL + 4, UI.MUTED);
        UI.text(g, "Clic gauche +1 · droit -1 · Maj ×16 · Ctrl retire", gx(), gy() + ROWS * CELL + 13, 0xFF5E667A);
    }

    @Override
    protected void renderLate(GuiGraphics g, int mx, int my) {
        CKit k = ClientState.kit(name);
        if (k == null) return;
        int i = slotAt(mx, my);
        if (i >= 0 && i < k.items.size()) g.renderTooltip(font, k.items.get(i), mx, my);
    }

    private int slotAt(double mx, double my) {
        if (!UI.in(mx, my, gx(), gy(), COLS * CELL, ROWS * CELL)) return -1;
        int c = ((int) mx - gx()) / CELL, r = ((int) my - gy()) / CELL;
        return r * COLS + c;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        CKit k = ClientState.kit(name);
        int i = slotAt(mx, my);
        if (k == null || i < 0 || i >= k.items.size()) return false;
        UI.click();
        if (hasControlDown()) { Act.of("kit.remove").s("name", name).n("index", i).send(); return true; }
        int step = hasShiftDown() ? 16 : 1;
        Act.of("kit.adjust").s("name", name).n("index", i).n("delta", button == 1 ? -step : step).send();
        return true;
    }
}
