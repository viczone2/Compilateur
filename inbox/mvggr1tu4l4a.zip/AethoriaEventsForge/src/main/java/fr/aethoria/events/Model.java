package fr.aethoria.events;

import net.minecraft.ChatFormatting;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.world.item.ItemStack;
import java.util.*;

class EvTeam {
    String name; ChatFormatting color = ChatFormatting.WHITE; Loc respawn, flag;
    List<String> classes = new ArrayList<>(); Set<UUID> members = new LinkedHashSet<>();
    int points; UUID flagCarrier; boolean flagHome = true; long flagLock;
    EvTeam(String n) { name = n; }
    String colored() { return color + name + ChatFormatting.RESET; }
}

class EvKit {
    String name; List<ItemStack> items = new ArrayList<>(); int limit = 0; boolean medic;
    EvKit(String n) { name = n; }
}

class EvZone {
    String name; Loc center; double radius = 6; int seconds = 20;
    String owner, captor; double progress; ServerBossEvent bar;
    String type = "NORMAL"; String hq; int hold; String note;
    EvZone(String n) { name = n; }
}
