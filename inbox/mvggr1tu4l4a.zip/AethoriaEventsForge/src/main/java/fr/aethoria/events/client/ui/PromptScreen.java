package fr.aethoria.events.client.ui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.function.Consumer;

/** Petite fenetre de saisie de texte (noms d'equipes, de kits, de zones). */
public final class PromptScreen extends BaseScreen {
    private final String prompt, initial;
    private final Consumer<String> ok;
    private EditBox box;

    public PromptScreen(String heading, String prompt, String initial, Screen back, Consumer<String> ok) {
        super(heading, back);
        this.prompt = prompt; this.initial = initial; this.ok = ok;
    }

    @Override protected int panelW() { return 320; }
    @Override protected int panelH() { return 140; }

    @Override
    protected void build() {
        box = new EditBox(font, px + 16, py + 62, pw - 32, 20, Component.literal(prompt));
        box.setMaxLength(24);
        box.setValue(initial);
        addRenderableWidget(box);
        setInitialFocus(box);
        box.setFocused(true);
        int bw = (pw - 40) / 2;
        btn(px + 16, py + 92, bw, 20, "Annuler", UiButton.Style.NORMAL, () -> minecraft.setScreen(back));
        btn(px + 24 + bw, py + 92, bw, 20, "Valider", UiButton.Style.SUCCESS, this::submit);
    }

    private void submit() {
        String v = box.getValue().trim();
        if (v.isEmpty()) return;
        ok.accept(v);
        minecraft.setScreen(back);
    }

    @Override
    protected void renderContent(GuiGraphics g, int mx, int my, float pt) {
        UI.text(g, UI.fit(prompt, pw - 32), px + 16, py + 46, UI.MUTED);
        UI.text(g, "Lettres, chiffres, _ et - uniquement (24 max).", px + 16, py + 116, 0xFF5E667A);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == 257 || key == 335) { submit(); return true; }
        return super.keyPressed(key, scan, mods);
    }

    /** Pas de reconstruction : on ne perd pas le texte en cours de saisie. */
    @Override public void refresh() { }
}
