package fr.aethoria.events.client.ui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.network.chat.Component;

/** Pastille de couleur cliquable. */
public final class Swatch extends AbstractWidget {
    private final int rgb;
    private final boolean selected;
    private final Runnable action;

    public Swatch(int x, int y, int w, int h, int rgb, boolean selected, Runnable action) {
        super(x, y, w, h, Component.literal(""));
        this.rgb = 0xFF000000 | rgb; this.selected = selected; this.action = action;
    }

    @Override
    public void renderWidget(GuiGraphics g, int mx, int my, float pt) {
        int x = getX(), y = getY();
        if (selected) UI.fillRound(g, x - 2, y - 2, width + 4, height + 4, 4, UI.GOLD);
        else if (isHoveredOrFocused()) UI.fillRound(g, x - 1, y - 1, width + 2, height + 2, 4, 0xFFB8C0D0);
        UI.fillRound(g, x, y, width, height, 3, rgb);
    }

    @Override
    public void onClick(double mx, double my) { action.run(); }

    @Override
    public void updateWidgetNarration(NarrationElementOutput out) { defaultButtonNarrationText(out); }
}
