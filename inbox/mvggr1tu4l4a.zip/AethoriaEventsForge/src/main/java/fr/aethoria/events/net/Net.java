package fr.aethoria.events.net;

import fr.aethoria.events.AethoriaEvents;
import fr.aethoria.events.Snapshots;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;
import java.util.UUID;

public final class Net {
    private Net() {}

    private static final String PROTOCOL = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(AethoriaEvents.MODID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public static void init() {
        int id = 0;
        CH.registerMessage(id++, S2CSnapshot.class, S2CSnapshot::encode, S2CSnapshot::decode, S2CSnapshot::handle);
        CH.registerMessage(id++, S2CHud.class, S2CHud::encode, S2CHud::decode, S2CHud::handle);
        CH.registerMessage(id++, C2SAction.class, C2SAction::encode, C2SAction::decode, C2SAction::handle);
    }

    public static void toPlayer(ServerPlayer p, Object msg) {
        CH.send(PacketDistributor.PLAYER.with(() -> p), msg);
    }

    public static void toServer(Object msg) { CH.sendToServer(msg); }

    /** Envoie l'etat complet au joueur ; "open" (nullable) ouvre l'ecran correspondant, "toast" affiche un message. */
    public static void sendSnapshot(ServerPlayer p, String open, UUID statsTarget, String toast, boolean ok) {
        CompoundTag t = Snapshots.build(p, statsTarget);
        if (open != null) t.putString("open", open);
        if (toast != null && !toast.isEmpty()) { t.putString("toast", toast); t.putBoolean("toastOk", ok); }
        toPlayer(p, new S2CSnapshot(t));
    }

    public static void openScreen(ServerPlayer p, String screen) { sendSnapshot(p, screen, null, null, true); }

    /** tag = null : efface l'interface de jeu (fin de partie). */
    public static void sendHud(ServerPlayer p, CompoundTag tag) { toPlayer(p, new S2CHud(tag)); }
}
