package fr.aethoria.events.client.ui;

import fr.aethoria.events.client.ClientState;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.ArrayList;
import java.util.List;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/** Fenetre commune : fond assombri, panneau, en-tete, bouton retour, message d'etat, listes defilantes. */
public abstract class BaseScreen extends Screen {
    protected final Screen back;
    protected final String heading;
    protected int px, py, pw, ph;
    protected final List<ScrollList> lists = new ArrayList<>();
    private final List<Object[]> texts = new ArrayList<>();
    protected final ScrollList mainList = new ScrollList();
    protected final ScrollList sideList = new ScrollList();

    protected BaseScreen(String heading, Screen back) {
        super(Component.literal(heading));
        this.heading = heading; this.back = back;
    }

    protected int panelW() { return 430; }
    protected int panelH() { return 300; }
    protected String subtitle() { return ""; }

    protected int cx() { return px + 12; }
    protected int cy() { return py + 40; }
    protected int cw() { return pw - 24; }
    /** Hauteur utile, au-dessus de la barre de message. */
    protected int ch() { return ph - 40 - 30; }

    protected abstract void build();

    public void refresh() { rebuildWidgets(); }

    @Override
    protected void init() {
        pw = Math.min(panelW(), width - 12);
        ph = Math.min(panelH(), height - 12);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        lists.clear();
        texts.clear();
        if (back != null) addRenderableWidget(new UiButton(px + 8, py + 8, 54, 18, "‹ Retour", UiButton.Style.GHOST, () -> minecraft.setScreen(back)));
        addRenderableWidget(new UiButton(px + pw - 26, py + 8, 18, 18, "X", UiButton.Style.GHOST, this::onClose));
        build();
    }

    // ------------------------------------------------------------------ aides de construction
    protected UiButton btn(int x, int y, int w, int h, String label, UiButton.Style s, Runnable r) {
        return addRenderableWidget(new UiButton(x, y, w, h, label, s, r));
    }

    protected ScrollList list(int x, int y, int w, int h) {
        ScrollList l = mainList;
        l.bounds(x, y, w, h);
        l.rows.clear();
        if (!lists.contains(l)) lists.add(l);
        return l;
    }

    protected void label(int x, int y, String s, int color) { texts.add(new Object[]{x, y, s, color, 0}); }
    protected void labelC(int cx, int y, String s, int color) { texts.add(new Object[]{cx, y, s, color, 1}); }
    protected void labelR(int rx, int y, String s, int color) { texts.add(new Object[]{rx, y, s, color, 2}); }

    /** Rangee d'onglets. */
    protected void tabs(int x, int y, int w, String[] names, IntSupplier cur, IntConsumer set) {
        int n = names.length, tw = (w - (n - 1) * 4) / n;
        for (int i = 0; i < n; i++) {
            final int idx = i;
            btn(x + i * (tw + 4), y, tw, 20, names[i], UiButton.Style.NORMAL, () -> { set.accept(idx); rebuildWidgets(); }).selected(cur.getAsInt() == i);
        }
    }

    /** Ligne "libelle [-big][-small] valeur [+small][+big]". */
    protected void stepper(int x, int y, int w, String text, String value, int small, int big, IntConsumer onDelta) {
        int bw = 26, vw = 62;
        int right = x + w;
        int bx = right - (bw * 4 + 2 * 2 + 4 * 2 + vw);
        label(x, y + 6, text, UI.TEXT);
        btn(bx, y, bw, 20, "-" + big, UiButton.Style.NORMAL, () -> onDelta.accept(-big));
        btn(bx + bw + 2, y, bw, 20, "-" + small, UiButton.Style.NORMAL, () -> onDelta.accept(-small));
        int vx = bx + 2 * bw + 6;
        labelC(vx + vw / 2, y + 6, value, UI.GOLD);
        btn(vx + vw + 4, y, bw, 20, "+" + small, UiButton.Style.NORMAL, () -> onDelta.accept(small));
        btn(vx + vw + 4 + bw + 2, y, bw, 20, "+" + big, UiButton.Style.NORMAL, () -> onDelta.accept(big));
    }

    protected void renderContent(GuiGraphics g, int mx, int my, float pt) { }
    protected void renderLate(GuiGraphics g, int mx, int my) { }

    // ------------------------------------------------------------------ rendu
    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        UI.fillRound(g, px - 2, py - 2, pw + 4, ph + 4, 9, 0x66000000);
        UI.roundBorder(g, px, py, pw, ph, 7, UI.LINE, UI.PANEL);
        UI.fillRound(g, px + 1, py + 1, pw - 2, 32, 6, UI.PANEL_HI);
        g.fill(px + 8, py + 34, px + pw - 8, py + 35, UI.LINE);
        int tx = back != null ? px + 68 : px + 14;
        String sub = subtitle();
        UI.text(g, "§l" + UI.fit(heading, pw - (tx - px) - 40), tx, sub.isEmpty() ? py + 13 : py + 8, UI.GOLD);
        if (!sub.isEmpty()) UI.text(g, UI.fit(sub, pw - (tx - px) - 40), tx, py + 20, UI.MUTED);

        for (Object[] t : texts) {
            int x = (Integer) t[0], y = (Integer) t[1], c = (Integer) t[3], mode = (Integer) t[4];
            String s = (String) t[2];
            if (mode == 1) UI.textC(g, s, x, y, c); else if (mode == 2) UI.textR(g, s, x, y, c); else UI.text(g, s, x, y, c);
        }
        renderContent(g, mx, my, pt);
        for (ScrollList l : lists) l.render(g, mx, my);
        super.render(g, mx, my, pt);

        for (GuiEventListener c : children()) {
            if (c instanceof UiButton) {
                UiButton b = (UiButton) c;
                if (b.isHoveredOrFocused() && !b.tooltip().isEmpty()) { g.renderComponentTooltip(font, b.tooltip(), mx, my); }
            }
        }
        for (ScrollList l : lists) {
            List<Component> tip = l.tooltipAt(mx, my);
            if (tip != null && !tip.isEmpty()) g.renderComponentTooltip(font, tip, mx, my);
        }
        renderLate(g, mx, my);

        long now = System.currentTimeMillis();
        if (ClientState.toast != null && now < ClientState.toastUntil) {
            int col = ClientState.toastOk ? UI.GOOD : UI.BAD;
            int y = py + ph - 26;
            UI.fillRound(g, px + 12, y, pw - 24, 18, 4, UI.mix(UI.PANEL, col, 0.25f));
            UI.fillRound(g, px + 12, y + 3, 3, 12, 1, col);
            UI.text(g, UI.fit(ClientState.toast, pw - 50), px + 22, y + 5, UI.TEXT);
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        for (ScrollList l : lists) if (l.mouseClicked(mx, my, button)) return true;
        return false;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        for (ScrollList l : lists) if (l.mouseScrolled(mx, my, delta)) return true;
        return super.mouseScrolled(mx, my, delta);
    }

    @Override public boolean isPauseScreen() { return false; }

    @Override public void onClose() { minecraft.setScreen(null); }
}
