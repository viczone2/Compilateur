package fr.aethoria.events;

import fr.aethoria.events.net.Net;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.BannerBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Scoreboard;
import net.minecraftforge.common.ToolActions;
import org.joml.Vector3f;
import java.util.*;

/** Logique de partie (zones, QG, drapeaux, reapparition, reanimation). Singleton cote serveur. */
public final class Game {
    public static Game I;

    final MinecraftServer server;
    final Store st = new Store();
    final Stats stats = new Stats();

    boolean running, wasDeploying;
    long startMs, deployUntil, endMs;
    int half;
    EvTeam forcedWinner;
    final Map<UUID, String> choice = new HashMap<>();
    final Map<UUID, Long> prot = new HashMap<>();
    final Map<UUID, Long> resup = new HashMap<>();
    final Map<UUID, Long> downed = new HashMap<>();
    final Map<UUID, UUID> downer = new HashMap<>();
    final Map<UUID, UUID> pendingKiller = new HashMap<>();
    final Map<UUID, Integer> reviveProg = new HashMap<>();
    final Map<UUID, Long> respawnAt = new HashMap<>();
    final Set<UUID> cameras = new HashSet<>();
    final Map<UUID, ItemStack> helmets = new HashMap<>();
    final Set<UUID> auto = new HashSet<>();
    final Map<String, PlayerTeam> sbTeams = new HashMap<>();

    private long tickNo;
    private final List<Object[]> tasks = new ArrayList<>();

    Game(MinecraftServer s) {
        server = s;
        st.load();
        stats.load();
        AethoriaEvents.LOG.info("AethoriaEvents : {} équipes, {} kits, {} zones.", st.teams.size(), st.kits.size(), st.zones.size());
    }

    void shutdown() {
        if (running) finish(true);
        st.save();
        stats.save();
    }

    // ------------------------------------------------------------------ utilitaires
    EvTeam teamOf(UUID u) { for (EvTeam t : st.teams.values()) if (t.members.contains(u)) return t; return null; }
    int cfg(String k) { return st.get(k); }
    boolean flag(String k) { return st.bool(k); }
    boolean deploying() { return running && System.currentTimeMillis() < deployUntil; }
    static boolean isHq(EvZone z) { return "HQ".equals(z.type); }
    ServerPlayer player(UUID u) { return server.getPlayerList().getPlayer(u); }
    List<ServerPlayer> online() { return new ArrayList<>(server.getPlayerList().getPlayers()); }

    void schedule(int ticks, Runnable r) { tasks.add(new Object[]{tickNo + ticks, r}); }

    public void say(String m) { server.getPlayerList().broadcastSystemMessage(Component.literal("§6[Event] §f" + m), false); }

    static void tell(ServerPlayer p, String m) { p.sendSystemMessage(Component.literal("§6[Event] §f" + m)); }

    static void title(ServerPlayer p, String t, String sub, int in, int stay, int out) {
        p.connection.send(new ClientboundSetTitlesAnimationPacket(in, stay, out));
        p.connection.send(new ClientboundSetSubtitleTextPacket(Component.literal(sub)));
        p.connection.send(new ClientboundSetTitleTextPacket(Component.literal(t)));
    }

    static void sound(ServerPlayer p, net.minecraft.sounds.SoundEvent s, float vol, float pitch) {
        p.playNotifySound(s, SoundSource.PLAYERS, vol, pitch);
    }

    static BossEvent.BossBarColor barColor(ChatFormatting c) {
        switch (c) {
            case RED: case DARK_RED: return BossEvent.BossBarColor.RED;
            case BLUE: case DARK_BLUE: case AQUA: case DARK_AQUA: return BossEvent.BossBarColor.BLUE;
            case GREEN: case DARK_GREEN: return BossEvent.BossBarColor.GREEN;
            case YELLOW: case GOLD: return BossEvent.BossBarColor.YELLOW;
            case LIGHT_PURPLE: return BossEvent.BossBarColor.PINK;
            case DARK_PURPLE: return BossEvent.BossBarColor.PURPLE;
            default: return BossEvent.BossBarColor.WHITE;
        }
    }

    static net.minecraft.world.level.block.Block banner(ChatFormatting c) { return BannerBlock.byColor(Opts.dye(c)); }

    // ------------------------------------------------------------------ demarrage / arret
    String start() {
        if (running) return "Un événement est déjà en cours.";
        if (st.teams.size() < 2) return "Il faut au moins 2 équipes.";
        for (EvTeam t : st.teams.values()) if (t.respawn == null) return "L'équipe " + t.name + " n'a pas de point de respawn.";
        stats.newSession();
        forcedWinner = null;
        for (EvTeam t : st.teams.values()) { t.points = 0; t.flagCarrier = null; t.flagHome = true; }
        for (EvZone z : st.zones.values()) {
            z.owner = (isHq(z) && st.team(z.hq) != null) ? st.team(z.hq).name : null;
            z.captor = null; z.progress = 0; z.hold = 0; z.note = null;
            z.bar = new ServerBossEvent(Component.literal(z.name), BossEvent.BossBarColor.WHITE, BossEvent.BossBarOverlay.PROGRESS);
        }
        downed.clear(); downer.clear(); pendingKiller.clear(); reviveProg.clear(); resup.clear(); prot.clear(); choice.clear(); respawnAt.clear();
        auto.clear();
        for (ServerPlayer p : online()) {
            if (cameras.contains(p.getUUID()) || teamOf(p.getUUID()) != null) continue;
            smallest().members.add(p.getUUID()); auto.add(p.getUUID());
        }
        running = true; half = 0; startMs = System.currentTimeMillis();
        deployUntil = startMs + cfg("deploy-minutes") * 60000L;
        endMs = deployUntil + cfg("duration-minutes") * 60000L;
        wasDeploying = deploying();
        buildScoreboardTeams();
        for (EvTeam t : st.teams.values()) placeFlag(t);
        for (EvTeam t : st.teams.values()) for (UUID u : t.members) { ServerPlayer p = player(u); if (p != null) prepare(p); }
        if (wasDeploying) {
            for (ServerPlayer p : online()) if (teamOf(p.getUUID()) != null) title(p, "§6§lDÉPLOIEMENT", "§7Choisis ta classe avec /classe", 5, 60, 10);
            say("§aDéploiement : " + cfg("deploy-minutes") + " min sans combat. Choisissez votre classe avec §e/classe§a.");
        } else {
            for (ServerPlayer p : online()) if (teamOf(p.getUUID()) != null) title(p, "§6§lC'EST PARTI !", "§7Bonne chance", 5, 40, 10);
            say("§aL'événement commence ! §7(" + cfg("duration-minutes") + " min)");
        }
        pushHud();
        return null;
    }

    /** Termine le deploiement maintenant. */
    String go() {
        if (!running) return "Aucun événement en cours.";
        if (!deploying()) return "Le combat a déjà commencé.";
        deployUntil = System.currentTimeMillis();
        endMs = deployUntil + cfg("duration-minutes") * 60000L;
        return null;
    }

    void announceGo() {
        wasDeploying = false;
        for (ServerPlayer p : online()) if (teamOf(p.getUUID()) != null) {
            title(p, "§c§lAU COMBAT !", "§7Capturez les zones", 5, 40, 10);
            sound(p, SoundEvents.PLAYER_LEVELUP, 1f, 0.5f);
        }
        say("§c§lLe combat commence !");
    }

    EvTeam smallest() {
        EvTeam s = null;
        for (EvTeam t : st.teams.values()) if (s == null || t.members.size() < s.members.size()) s = t;
        return s;
    }

    void finish(boolean forced) {
        if (!running) return;
        running = false;
        EvTeam win = null; boolean tie = false;
        if (forcedWinner != null) win = forcedWinner;
        else for (EvTeam t : st.teams.values()) {
            if (win == null || t.points > win.points) { win = t; tie = false; }
            else if (t.points == win.points) tie = true;
        }
        say("§6§m------------------------");
        if (forced) say("§cÉvénement arrêté.");
        if (win == null || tie) say("§eÉgalité !");
        else say("§aVictoire de l'équipe " + win.colored() + " §a!");
        for (EvTeam t : st.teams.values()) say(t.colored() + " §f: " + t.points + " pts");
        say("§6§m------------------------");
        List<UUID> participants = new ArrayList<>();
        for (EvTeam t : st.teams.values()) for (UUID u : t.members) {
            ServerPlayer p = player(u);
            if (p == null) continue;
            participants.add(u);
            stats.add(p, Stats.G, 1);
            if (!tie && win == t) stats.add(p, Stats.W, 1);
        }
        for (EvZone z : st.zones.values()) if (z.bar != null) { z.bar.removeAllPlayers(); z.bar = null; }
        for (EvTeam t : st.teams.values()) {
            if (t.flagCarrier != null) returnFlag(t, null);
            if (t.flag != null) removeFlagBlock(t);
            t.flagCarrier = null; t.flagHome = true;
        }
        helmets.clear();
        for (ServerPlayer p : online()) {
            if (teamOf(p.getUUID()) == null) continue;
            clearEffects(p);
            p.setGameMode(GameType.SURVIVAL);
            Net.sendHud(p, null);
        }
        removeScoreboardTeams();
        for (UUID u : auto) for (EvTeam t : st.teams.values()) t.members.remove(u);
        auto.clear(); prot.clear(); choice.clear(); downed.clear(); downer.clear(); pendingKiller.clear(); reviveProg.clear(); respawnAt.clear();
        forcedWinner = null;
        stats.save();
        // classement affiche a l'ecran des participants
        schedule(40, () -> { for (UUID u : participants) { ServerPlayer p = player(u); if (p != null) Net.openScreen(p, "stats"); } });
    }

    void clearEffects(ServerPlayer p) { p.removeAllEffects(); }

    // ------------------------------------------------------------------ preparation / kits
    void prepare(ServerPlayer p) {
        EvTeam t = teamOf(p.getUUID());
        if (t == null) return;
        p.setGameMode(GameType.SURVIVAL);
        p.setHealth(p.getMaxHealth()); p.getFoodData().setFoodLevel(20); p.getFoodData().setSaturation(20f); p.clearFire();
        clearEffects(p);
        t.respawn.teleport(p);
        PlayerTeam pt = sbTeams.get(t.name);
        if (pt != null) server.getScoreboard().addPlayerToTeam(p.getScoreboardName(), pt);
        giveClassKit(p, t);
        protect(p, cfg("protection-seconds"));
        if (t.classes.size() > 1 && !choice.containsKey(p.getUUID()))
            schedule(20, () -> { if (running && !p.hasDisconnected()) Net.openScreen(p, "class"); });
    }

    void protect(ServerPlayer p, int s) {
        if (s > 0) prot.put(p.getUUID(), System.currentTimeMillis() + s * 1000L);
    }

    EvKit kitOf(ServerPlayer p, EvTeam t) {
        String cn = choice.get(p.getUUID());
        EvKit k = cn == null ? null : st.kits.get(cn);
        if (k != null && t.classes.contains(k.name)) return k;
        for (String c : t.classes) if (st.kits.containsKey(c)) return st.kits.get(c);
        return null;
    }

    boolean isMedic(ServerPlayer p) {
        EvTeam t = teamOf(p.getUUID());
        if (t == null) return false;
        EvKit k = kitOf(p, t);
        return k != null && k.medic;
    }

    void giveClassKit(ServerPlayer p, EvTeam t) {
        EvKit k = kitOf(p, t);
        if (k != null) giveKit(p, k);
        else p.getInventory().clearContent();
    }

    static EquipmentSlot slotFor(ItemStack s) {
        if (s.getItem() instanceof ArmorItem) return ((ArmorItem) s.getItem()).getEquipmentSlot();
        if (s.canPerformAction(ToolActions.SHIELD_BLOCK)) return EquipmentSlot.OFFHAND;
        return null;
    }

    static void giveKit(ServerPlayer p, EvKit k) {
        p.getInventory().clearContent();
        for (ItemStack raw : k.items) {
            ItemStack s = raw.copy();
            EquipmentSlot slot = slotFor(s);
            if (slot != null && p.getItemBySlot(slot).isEmpty()) p.setItemSlot(slot, s);
            else if (!p.getInventory().add(s)) p.drop(s, false);
        }
        p.inventoryMenu.broadcastChanges();
    }

    String choose(ServerPlayer p, EvKit k) {
        if (!running) return "Aucun événement en cours.";
        EvTeam t = teamOf(p.getUUID());
        if (t == null || !t.classes.contains(k.name)) return "Classe indisponible pour ton équipe.";
        int lim = k.limit > 0 ? k.limit : cfg("default-class-limit");
        if (lim > 0) {
            int n = 0;
            for (UUID u : t.members) if (!u.equals(p.getUUID()) && k.name.equals(choice.get(u))) n++;
            if (n >= lim) return "Classe complète (" + lim + " max par équipe).";
        }
        choice.put(p.getUUID(), k.name);
        boolean near = t.respawn.sameDim(p) && dist2(p, t.respawn) <= 100;
        if (deploying() || near || System.currentTimeMillis() - startMs < 30000L) {
            giveKit(p, k);
            return "§aClasse " + k.name + " équipée !";
        }
        return "§aClasse " + k.name + " choisie : elle sera équipée à ta prochaine réapparition.";
    }

    static double dist2(ServerPlayer p, Loc l) {
        double dx = p.getX() - l.x, dy = p.getY() - l.y, dz = p.getZ() - l.z;
        return dx * dx + dy * dy + dz * dz;
    }

    String resupply(ServerPlayer p) {
        if (!running) return "Aucun événement en cours.";
        EvTeam t = teamOf(p.getUUID());
        if (t == null || !alive(p)) return "Indisponible.";
        if (!deploying()) {
            boolean ok = false;
            for (EvZone z : st.zones.values()) if ("DEPOT".equals(z.type) && z.owner != null && z.owner.equalsIgnoreCase(t.name)) ok = true;
            if (!ok) return "Ton équipe ne tient aucun dépôt.";
        }
        long now = System.currentTimeMillis();
        Long last = resup.get(p.getUUID());
        long cd = cfg("resupply-cooldown") * 1000L;
        if (last != null && now < last + cd) return "Patiente encore " + ((last + cd - now) / 1000 + 1) + "s.";
        resup.put(p.getUUID(), now);
        giveClassKit(p, t);
        return "§aRéapprovisionnement effectué !";
    }

    // ------------------------------------------------------------------ boucle
    /** Appele a chaque tick serveur. */
    void serverTick() {
        tickNo++;
        if (!tasks.isEmpty()) {
            List<Object[]> due = new ArrayList<>();
            for (Iterator<Object[]> it = tasks.iterator(); it.hasNext(); ) {
                Object[] t = it.next();
                if ((Long) t[0] <= tickNo) { due.add(t); it.remove(); }
            }
            for (Object[] t : due) { try { ((Runnable) t[1]).run(); } catch (Throwable ex) { AethoriaEvents.LOG.warn("tâche: {}", ex.toString()); } }
        }
        if (running && tickNo % 10 == 0) tick();
    }

    void tick() {
        if (!running) return;
        half++;
        if (flag("zone-outline")) { try { drawZones(); } catch (Throwable ex) { AethoriaEvents.LOG.warn("outline: {}", ex.toString()); } }
        try { processRespawns(); } catch (Throwable ex) { AethoriaEvents.LOG.warn("respawn: {}", ex.toString()); }
        if (deploying()) { if (half % 2 == 0) pushHud(); return; }
        if (wasDeploying) announceGo();
        try { updateZones(); updateFlags(); updateRevives(); } catch (Exception ex) { AethoriaEvents.LOG.warn("tick: {}", ex.toString()); }
        if (half % 2 == 0) {
            int sec = half / 2;
            int interval = Math.max(1, cfg("zone-points-interval"));
            if (sec % interval == 0) for (EvZone z : st.zones.values()) {
                if (isHq(z)) continue;
                EvTeam o = z.owner == null ? null : st.team(z.owner);
                if (o != null) o.points += cfg("zone-points");
            }
            for (EvZone z : st.zones.values()) {
                if (!isHq(z)) continue;
                EvTeam o = z.owner == null ? null : st.team(z.owner);
                EvTeam d = st.team(z.hq);
                if (o != null && o != d) {
                    z.hold++;
                    if (z.hold >= cfg("hq-hold-seconds")) {
                        forcedWinner = o;
                        say("L'équipe " + o.colored() + " §fa tenu le QG §e" + z.name + " §f!");
                        finish(false);
                        return;
                    }
                } else z.hold = 0;
            }
            pushHud();
            int lim = cfg("score-limit");
            boolean over = System.currentTimeMillis() >= endMs;
            for (EvTeam t : st.teams.values()) if (lim > 0 && t.points >= lim) over = true;
            if (over) finish(false);
        }
    }

    boolean alive(ServerPlayer p) {
        UUID u = p.getUUID();
        return !p.hasDisconnected() && p.isAlive() && p.gameMode.getGameModeForPlayer() == GameType.SURVIVAL
                && !downed.containsKey(u) && !respawnAt.containsKey(u);
    }

    boolean inside(ServerPlayer p, EvZone z) {
        Loc c = z.center;
        if (c == null || !c.sameDim(p)) return false;
        double dx = p.getX() - c.x, dz = p.getZ() - c.z;
        return dx * dx + dz * dz <= z.radius * z.radius && Math.abs(p.getY() - c.y) <= 12;
    }

    int ownedCount(EvTeam t) {
        int n = 0;
        for (EvZone z : st.zones.values()) if (!isHq(z) && z.owner != null && z.owner.equalsIgnoreCase(t.name)) n++;
        return n;
    }

    void updateZones() {
        List<ServerPlayer> players = online();
        for (EvZone z : st.zones.values()) {
            Map<EvTeam, List<ServerPlayer>> present = new LinkedHashMap<>();
            Set<ServerPlayer> anyone = new HashSet<>();
            for (ServerPlayer p : players) {
                if (!alive(p) || !inside(p, z)) continue;
                anyone.add(p);
                EvTeam t = teamOf(p.getUUID());
                if (t != null) present.computeIfAbsent(t, k -> new ArrayList<>()).add(p);
            }
            double rate = 0.5 / Math.max(1, z.seconds);
            EvTeam owner = z.owner == null ? null : st.team(z.owner);
            boolean hq = isHq(z);
            z.note = null;
            boolean blocked = false;
            if (present.size() == 1) {
                EvTeam t = present.keySet().iterator().next();
                if (t != owner) {
                    if (hq) {
                        EvTeam d = st.team(z.hq);
                        if (t != d && ownedCount(t) < cfg("hq-required-zones")) { blocked = true; z.note = "verrouillé : " + cfg("hq-required-zones") + " zones requises"; }
                    } else {
                        int max = cfg("max-zones-per-team");
                        if (max > 0 && ownedCount(t) >= max) { blocked = true; z.note = "limite de " + max + " zones atteinte"; }
                    }
                }
            }
            if (present.size() == 1 && !blocked) {
                EvTeam t = present.keySet().iterator().next();
                if (t == owner) {
                    if (z.captor != null) { z.progress -= rate * 2; if (z.progress <= 0) { z.progress = 0; z.captor = null; } }
                } else if (z.captor != null && !z.captor.equals(t.name)) {
                    z.progress -= rate * 2;
                    if (z.progress <= 0) { z.progress = 0; z.captor = t.name; }
                } else {
                    z.captor = t.name; z.progress += rate;
                    if (z.progress >= 1) capture(z, t, present.get(t));
                }
            } else if ((present.isEmpty() || blocked) && z.captor != null) {
                z.progress -= rate / 2;
                if (z.progress <= 0) { z.progress = 0; z.captor = null; }
            }
            updateBar(z, anyone, players);
        }
    }

    void capture(EvZone z, EvTeam t, List<ServerPlayer> who) {
        z.owner = t.name; z.captor = null; z.progress = 0; z.hold = 0;
        if (!isHq(z)) t.points += cfg("zone-capture-points");
        for (ServerPlayer p : who) stats.add(p, Stats.Z, 1);
        say("L'équipe " + t.colored() + " §fa capturé " + (isHq(z) ? "le QG " : "la zone ") + "§e" + z.name + " §f!");
        for (ServerPlayer p : online()) if (teamOf(p.getUUID()) != null) sound(p, SoundEvents.PLAYER_LEVELUP, 1f, 1f);
    }

    void updateBar(EvZone z, Set<ServerPlayer> inside, List<ServerPlayer> players) {
        ServerBossEvent b = z.bar;
        if (b == null) return;
        EvTeam cap = z.captor == null ? null : st.team(z.captor);
        EvTeam own = z.owner == null ? null : st.team(z.owner);
        EvTeam def = st.team(z.hq);
        String label = (isHq(z) ? "§c§lQG " : "") + "§e" + z.name;
        String title; double prog; ChatFormatting col = ChatFormatting.WHITE;
        if (isHq(z) && own != null && own != def) {
            int need = Math.max(1, cfg("hq-hold-seconds"));
            title = label + " §7- tenu par " + own.colored() + " §7" + z.hold + "/" + need + "s";
            prog = Math.max(0, Math.min(1, (double) z.hold / need)); col = own.color;
        } else if (cap != null) {
            title = label + " §7- Capture par " + cap.colored() + " §7" + (int) (z.progress * 100) + "%";
            prog = Math.max(0, Math.min(1, z.progress)); col = cap.color;
        } else if (own != null) {
            title = label + " §7- Contrôlée par " + own.colored(); prog = 1.0; col = own.color;
        } else { title = label + " §7- Neutre"; prog = 0.0; }
        if (z.note != null) title += " §8(" + z.note + ")";
        b.setName(Component.literal(title)); b.setProgress((float) prog); b.setColor(barColor(col));
        for (ServerPlayer p : players) { if (inside.contains(p)) b.addPlayer(p); else b.removePlayer(p); }
    }

    // ------------------------------------------------------------------ a terre / reanimation / elimination
    void down(ServerPlayer p, ServerPlayer by) {
        UUID u = p.getUUID();
        EvTeam t = teamOf(u);
        downed.put(u, System.currentTimeMillis() + cfg("revive-seconds") * 1000L);
        if (by != null && !by.equals(p)) downer.put(u, by.getUUID());
        p.setHealth(4.0f); p.clearFire();
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 1000000, 5, false, false));
        p.addEffect(new MobEffectInstance(MobEffects.GLOWING, 1000000, 0, false, false));
        for (EvTeam f : st.teams.values()) if (u.equals(f.flagCarrier)) returnFlag(f, "Le porteur est à terre.");
        title(p, "§c§lÀ TERRE", "§7Un médecin peut te relever", 0, 40, 10);
        if (t != null) for (UUID m : t.members) {
            ServerPlayer mp = player(m);
            if (mp != null && !m.equals(u)) mp.sendSystemMessage(Component.literal("§6[Event] §c" + p.getGameProfile().getName() + " §fest à terre ! Un médecin peut le relever."));
        }
    }

    void updateRevives() {
        if (downed.isEmpty()) return;
        long now = System.currentTimeMillis();
        List<ServerPlayer> players = online();
        for (UUID u : new ArrayList<>(downed.keySet())) {
            ServerPlayer p = player(u);
            if (p == null) { downed.remove(u); reviveProg.remove(u); continue; }
            EvTeam t = teamOf(u);
            if (now >= downed.get(u)) { bleedOut(p); continue; }
            ServerPlayer healer = null;
            for (ServerPlayer m : players) {
                if (m.equals(p) || !alive(m) || teamOf(m.getUUID()) != t || !isMedic(m) || !m.isShiftKeyDown()) continue;
                if (m.level() != p.level() || m.distanceToSqr(p) > 9) continue;
                healer = m; break;
            }
            int need = Math.max(1, cfg("revive-hold-seconds")) * 2;
            if (healer != null) {
                int n = reviveProg.merge(u, 1, Integer::sum);
                title(healer, "", "§aRéanimation de " + p.getGameProfile().getName() + " : " + (n * 100 / need) + "%", 0, 12, 0);
                if (n >= need) revive(p, healer);
            } else {
                reviveProg.remove(u);
                title(p, "§c§lÀ TERRE", "§7Mort dans " + ((downed.get(u) - now) / 1000 + 1) + "s", 0, 12, 0);
            }
        }
    }

    void clearDowned(UUID u) { downed.remove(u); reviveProg.remove(u); }

    void revive(ServerPlayer p, ServerPlayer healer) {
        UUID u = p.getUUID();
        clearDowned(u); downer.remove(u);
        clearEffects(p);
        p.setHealth(10.0f);
        protect(p, 3);
        title(p, "§a§lRELEVÉ !", "§7par " + healer.getGameProfile().getName(), 0, 30, 10);
        EvTeam t = teamOf(u);
        if (t != null) say(healer.getGameProfile().getName() + " a relevé " + p.getGameProfile().getName() + " §7(" + t.colored() + "§7)");
    }

    void bleedOut(ServerPlayer p) {
        UUID u = p.getUUID();
        UUID by = downer.remove(u);
        clearDowned(u);
        ServerPlayer killer = by == null ? null : player(by);
        eliminate(p, killer);
    }

    /** Mort "propre" : pas de vraie mort, le joueur passe en spectateur puis reapparait a sa base. */
    void eliminate(ServerPlayer p, ServerPlayer killer) {
        UUID u = p.getUUID();
        EvTeam t = teamOf(u);
        if (t == null || respawnAt.containsKey(u)) return;
        clearDowned(u); downer.remove(u); pendingKiller.remove(u);
        stats.add(p, Stats.D, 1);
        if (killer == null && p.getKillCredit() instanceof ServerPlayer) killer = (ServerPlayer) p.getKillCredit();
        String by = "";
        if (killer != null && !killer.equals(p)) {
            EvTeam kt = teamOf(killer.getUUID());
            if (kt != null && kt != t) { stats.add(killer, Stats.K, 1); kt.points += cfg("kill-points"); }
            by = " §7par " + killer.getGameProfile().getName();
        }
        say(t.color + p.getGameProfile().getName() + " §7a été éliminé" + by + "§7.");
        for (EvTeam f : st.teams.values()) if (u.equals(f.flagCarrier)) returnFlag(f, "Le porteur est mort.");
        clearEffects(p);
        p.getInventory().clearContent();
        p.setHealth(p.getMaxHealth()); p.clearFire(); p.fallDistance = 0;
        p.setGameMode(GameType.SPECTATOR);
        t.respawn.teleport(p);
        respawnAt.put(u, System.currentTimeMillis() + Math.max(0, cfg("respawn-delay")) * 1000L);
    }

    void processRespawns() {
        if (respawnAt.isEmpty()) return;
        long now = System.currentTimeMillis();
        for (UUID u : new ArrayList<>(respawnAt.keySet())) {
            ServerPlayer p = player(u);
            EvTeam t = teamOf(u);
            if (p == null || t == null) { respawnAt.remove(u); continue; }
            long left = respawnAt.get(u) - now;
            if (left <= 0) {
                respawnAt.remove(u);
                p.setGameMode(GameType.SURVIVAL); t.respawn.teleport(p);
                p.setHealth(p.getMaxHealth()); p.getFoodData().setFoodLevel(20); p.clearFire(); clearEffects(p);
                giveClassKit(p, t); protect(p, cfg("protection-seconds"));
                title(p, "§aEn avant !", "", 0, 20, 10);
            } else {
                title(p, "§cRéapparition", "§f" + (left / 1000 + 1), 0, 14, 0);
            }
        }
    }

    // ------------------------------------------------------------------ drapeaux
    void placeFlag(EvTeam t) {
        if (t.flag == null) return;
        ServerLevel l = t.flag.level(server);
        if (l != null) l.setBlockAndUpdate(t.flag.pos(), banner(t.color).defaultBlockState());
    }

    void removeFlagBlock(EvTeam t) {
        ServerLevel l = t.flag == null ? null : t.flag.level(server);
        if (l != null) l.setBlockAndUpdate(t.flag.pos(), Blocks.AIR.defaultBlockState());
    }

    boolean near(ServerPlayer p, Loc b, double r) {
        if (b == null || !b.sameDim(p)) return false;
        double dx = p.getX() - b.x - 0.5, dz = p.getZ() - b.z - 0.5;
        return dx * dx + dz * dz <= r * r && Math.abs(p.getY() - b.y) <= 3;
    }

    void holdFlag(ServerPlayer p, EvTeam stolen) {
        UUID u = p.getUUID();
        if (!helmets.containsKey(u)) helmets.put(u, p.getItemBySlot(EquipmentSlot.HEAD).copy());
        net.minecraft.world.level.block.Block bl = banner(stolen.color);
        ItemStack h = p.getItemBySlot(EquipmentSlot.HEAD);
        if (h.isEmpty() || h.getItem() != bl.asItem()) {
            ItemStack f = new ItemStack(bl);
            f.setHoverName(Component.literal("§c⚑ Drapeau de " + stolen.name));
            p.setItemSlot(EquipmentSlot.HEAD, f);
        }
    }

    void dropHeadFlag(ServerPlayer p) {
        UUID u = p.getUUID();
        if (!helmets.containsKey(u)) return;
        p.setItemSlot(EquipmentSlot.HEAD, helmets.remove(u));
    }

    void updateFlags() {
        long now = System.currentTimeMillis();
        List<ServerPlayer> players = online();
        for (EvTeam t : st.teams.values()) {
            if (t.flag != null && t.flagHome && now >= t.flagLock) {
                for (ServerPlayer p : players) {
                    EvTeam pt = teamOf(p.getUUID());
                    if (pt == null || pt == t || !alive(p) || !near(p, t.flag, 1.6)) continue;
                    boolean already = false;
                    for (EvTeam o : st.teams.values()) if (p.getUUID().equals(o.flagCarrier)) already = true;
                    if (already) continue;
                    t.flagHome = false; t.flagCarrier = p.getUUID();
                    removeFlagBlock(t);
                    holdFlag(p, t);
                    p.addEffect(new MobEffectInstance(MobEffects.GLOWING, 1000000, 0, false, false));
                    say(p.getGameProfile().getName() + " (" + pt.colored() + "§f) a volé le drapeau de " + t.colored() + " §f!");
                    break;
                }
            }
            if (t.flagCarrier != null) {
                ServerPlayer c = player(t.flagCarrier);
                if (c == null || !alive(c)) { returnFlag(t, "Le porteur a disparu."); continue; }
                holdFlag(c, t);
                EvTeam own = teamOf(c.getUUID());
                if (own != null && own != t && own.flag != null && near(c, own.flag, 2.0)) {
                    if (own.flagHome) {
                        int pts = cfg("flag-capture-points");
                        own.points += pts;
                        stats.add(c, Stats.F, 1);
                        say(c.getGameProfile().getName() + " a ramené le drapeau de " + t.colored() + " §fpour " + own.colored() + " §f(+" + pts + ") !");
                        returnFlag(t, null);
                    } else if (half % 4 == 0) title(c, "", "§cTon drapeau est volé ! Récupère-le d'abord", 0, 25, 5);
                }
            }
        }
    }

    void returnFlag(EvTeam t, String why) {
        if (t.flagCarrier != null) {
            ServerPlayer c = player(t.flagCarrier);
            if (c != null) {
                dropHeadFlag(c);
                if (!downed.containsKey(c.getUUID())) c.removeEffect(MobEffects.GLOWING);
            } else helmets.remove(t.flagCarrier);
        }
        t.flagCarrier = null; t.flagHome = true; t.flagLock = System.currentTimeMillis() + 5000L;
        placeFlag(t);
        if (why != null) say("Le drapeau de " + t.colored() + " §fest revenu à sa base. §7" + why);
    }

    // ------------------------------------------------------------------ contour des zones
    void drawZones() {
        List<ServerPlayer> players = online();
        for (EvZone z : st.zones.values()) {
            if (z.center == null) continue;
            ServerLevel lvl = z.center.level(server);
            if (lvl == null) continue;
            EvTeam cap = z.captor == null ? null : st.team(z.captor);
            EvTeam own = z.owner == null ? null : st.team(z.owner);
            int c = Opts.rgb(cap != null ? cap.color : own != null ? own.color : ChatFormatting.WHITE);
            DustParticleOptions dust = new DustParticleOptions(new Vector3f(((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f), 1.6f);
            int n = (int) Math.max(24, Math.min(100, 2 * Math.PI * z.radius / 1.5));
            double max = z.radius + 40;
            for (ServerPlayer p : players) {
                if (p.level() != lvl) continue;
                double dx = p.getX() - z.center.x, dz = p.getZ() - z.center.z;
                if (dx * dx + dz * dz > max * max) continue;
                double y = Math.max(z.center.y - 12, Math.min(z.center.y + 12, p.getY())) + 0.4;
                for (int i = 0; i < n; i++) {
                    double ang = 2 * Math.PI * i / n;
                    double x = z.center.x + Math.cos(ang) * z.radius, zz = z.center.z + Math.sin(ang) * z.radius;
                    lvl.sendParticles(p, dust, true, x, y, zz, 1, 0, 0, 0, 0);
                    if (i % 2 == 0) lvl.sendParticles(p, dust, true, x, y + 1.3, zz, 1, 0, 0, 0, 0);
                }
            }
        }
    }

    // ------------------------------------------------------------------ equipes de scoreboard (couleur / contour lumineux / tir allie)
    void buildScoreboardTeams() {
        removeScoreboardTeams();
        Scoreboard sb = server.getScoreboard();
        int i = 0;
        for (EvTeam t : st.teams.values()) {
            String id = "aev" + (i++);
            PlayerTeam old = sb.getPlayerTeam(id);
            if (old != null) sb.removePlayerTeam(old);
            PlayerTeam pt = sb.addPlayerTeam(id);
            pt.setColor(t.color.isColor() ? t.color : ChatFormatting.WHITE);
            pt.setAllowFriendlyFire(flag("friendly-fire"));
            pt.setSeeFriendlyInvisibles(true);
            sbTeams.put(t.name, pt);
        }
    }

    void removeScoreboardTeams() {
        Scoreboard sb = server.getScoreboard();
        for (PlayerTeam pt : sbTeams.values()) {
            try { if (sb.getPlayerTeam(pt.getName()) != null) sb.removePlayerTeam(pt); } catch (Exception ignored) { }
        }
        sbTeams.clear();
    }

    // ------------------------------------------------------------------ HUD (envoye aux joueurs de l'evenement)
    void pushHud() {
        for (ServerPlayer p : online()) {
            if (teamOf(p.getUUID()) == null && !cameras.contains(p.getUUID())) continue;
            Net.sendHud(p, hudTag(p));
        }
    }

    CompoundTag hudTag(ServerPlayer p) {
        CompoundTag t = new CompoundTag();
        long now = System.currentTimeMillis();
        boolean dep = deploying();
        t.putBoolean("deploy", dep);
        t.putLong("ms", Math.max(0, dep ? deployUntil - now : endMs - now));
        List<EvTeam> ts = new ArrayList<>(st.teams.values());
        ts.sort((a, b) -> Integer.compare(b.points, a.points));
        ListTag tl = new ListTag();
        for (EvTeam e : ts) {
            CompoundTag c = new CompoundTag();
            c.putString("name", e.name); c.putInt("rgb", Opts.rgb(e.color)); c.putInt("points", e.points); c.putBoolean("stolen", !e.flagHome);
            tl.add(c);
        }
        t.put("teams", tl);
        ListTag zl = new ListTag();
        for (EvZone z : st.zones.values()) {
            EvTeam o = z.owner == null ? null : st.team(z.owner);
            EvTeam cap = z.captor == null ? null : st.team(z.captor);
            EvTeam def = st.team(z.hq);
            CompoundTag c = new CompoundTag();
            c.putString("name", z.name); c.putBoolean("hq", isHq(z));
            c.putInt("owner", o == null ? -1 : Opts.rgb(o.color));
            c.putInt("captor", cap == null ? -1 : Opts.rgb(cap.color));
            c.putFloat("progress", (float) Math.max(0, Math.min(1, z.progress)));
            boolean attacked = isHq(z) && o != null && o != def;
            c.putInt("hold", attacked ? z.hold : 0);
            c.putInt("need", Math.max(1, cfg("hq-hold-seconds")));
            zl.add(c);
        }
        t.put("zones", zl);
        EvTeam me = teamOf(p.getUUID());
        t.putString("team", me == null ? "" : me.name);
        t.putInt("teamRgb", me == null ? 0xFFFFFF : Opts.rgb(me.color));
        EvKit k = me == null ? null : kitOf(p, me);
        t.putString("class", k == null ? "" : k.name);
        Long d = downed.get(p.getUUID());
        t.putLong("downedMs", d == null ? 0 : Math.max(0, d - now));
        return t;
    }

    // ------------------------------------------------------------------ evenements joueurs
    void onJoin(ServerPlayer p) {
        if (!running) return;
        if (cameras.contains(p.getUUID())) return;
        EvTeam t = teamOf(p.getUUID());
        if (t == null && flag("join-late")) {
            t = smallest(); t.members.add(p.getUUID()); auto.add(p.getUUID());
        }
        if (t != null) schedule(10, () -> { if (running && !p.hasDisconnected()) prepare(p); });
    }

    void onQuit(ServerPlayer p) {
        if (!running) return;
        UUID u = p.getUUID();
        clearDowned(u); respawnAt.remove(u);
        for (EvTeam f : st.teams.values()) if (u.equals(f.flagCarrier)) returnFlag(f, "Le porteur s'est déconnecté.");
    }
}
