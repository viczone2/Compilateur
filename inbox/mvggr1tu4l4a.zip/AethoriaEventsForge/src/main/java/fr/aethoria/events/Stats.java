package fr.aethoria.events;

import com.google.gson.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.fml.loading.FMLPaths;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Statistiques (config/aethoriaevents/stats.json) + classement de la manche en cours. */
public final class Stats {
    static final int K = 0, D = 1, Z = 2, F = 3, G = 4, W = 5;
    static final String[] KEYS = {"kills", "deaths", "zones", "flags", "games", "wins"};
    private final Path dir = FMLPaths.CONFIGDIR.get().resolve("aethoriaevents");
    private final Path file = dir.resolve("stats.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    final Map<UUID, int[]> total = new HashMap<>();
    final Map<UUID, String> names = new HashMap<>();
    final Map<UUID, int[]> session = new LinkedHashMap<>();
    final Map<UUID, String> sessionNames = new HashMap<>();

    void newSession() { session.clear(); sessionNames.clear(); }

    void add(ServerPlayer p, int idx, int n) {
        UUID u = p.getUUID();
        String nm = p.getGameProfile().getName();
        if (idx < 4) { session.computeIfAbsent(u, k -> new int[4])[idx] += n; sessionNames.put(u, nm); }
        names.put(u, nm);
        total.computeIfAbsent(u, k -> new int[6])[idx] += n;
    }

    int[] totals(UUID u) { return total.getOrDefault(u, new int[6]); }
    int[] sess(UUID u) { return session.get(u); }

    static int score(int[] s) { return s[K] * 3 + s[Z] * 5 + s[F] * 10; }

    /** Classement de la manche, du meilleur au moins bon. */
    List<Map.Entry<UUID, int[]>> ranking() {
        List<Map.Entry<UUID, int[]>> l = new ArrayList<>(session.entrySet());
        l.sort((a, b) -> Integer.compare(score(b.getValue()), score(a.getValue())));
        return l;
    }

    UUID find(String name, MinecraftServer s) {
        ServerPlayer p = s.getPlayerList().getPlayerByName(name);
        if (p != null) return p.getUUID();
        for (Map.Entry<UUID, String> e : names.entrySet()) if (e.getValue().equalsIgnoreCase(name)) return e.getKey();
        return null;
    }

    synchronized void save() {
        try {
            Files.createDirectories(dir);
            JsonObject root = new JsonObject();
            for (Map.Entry<UUID, int[]> e : total.entrySet()) {
                JsonObject o = new JsonObject();
                o.addProperty("name", names.getOrDefault(e.getKey(), "?"));
                for (int i = 0; i < KEYS.length; i++) o.addProperty(KEYS[i], e.getValue()[i]);
                root.add(e.getKey().toString(), o);
            }
            Path tmp = dir.resolve("stats.json.tmp");
            Files.write(tmp, GSON.toJson(root).getBytes(StandardCharsets.UTF_8));
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
        } catch (Exception ex) {
            AethoriaEvents.LOG.warn("stats.json: {}", ex.toString());
        }
    }

    void load() {
        if (!Files.exists(file)) return;
        try {
            JsonObject root = JsonParser.parseString(new String(Files.readAllBytes(file), StandardCharsets.UTF_8)).getAsJsonObject();
            for (Map.Entry<String, JsonElement> e : root.entrySet()) {
                try {
                    UUID u = UUID.fromString(e.getKey());
                    JsonObject o = e.getValue().getAsJsonObject();
                    int[] a = new int[6];
                    for (int i = 0; i < KEYS.length; i++) a[i] = o.has(KEYS[i]) ? o.get(KEYS[i]).getAsInt() : 0;
                    total.put(u, a);
                    if (o.has("name")) names.put(u, o.get("name").getAsString());
                } catch (Exception ignored) { }
            }
        } catch (Exception ex) {
            AethoriaEvents.LOG.error("Impossible de lire stats.json : {}", ex.toString());
        }
    }

    static String kd(int k, int d) { return String.format(Locale.ROOT, "%.2f", d == 0 ? (double) k : (double) k / d); }
}
