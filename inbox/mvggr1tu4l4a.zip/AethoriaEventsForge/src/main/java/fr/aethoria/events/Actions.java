package fr.aethoria.events;

import fr.aethoria.events.net.Net;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import java.util.UUID;

/** Actions envoyees par les interfaces client. Toutes les actions d'administration exigent le niveau op 2. */
public final class Actions {
    private Actions() {}

    private static final String SILENT = "\u0000";

    public static void handle(ServerPlayer p, String a, CompoundTag args) {
        Game g = Game.I;
        if (g == null) return;
        String res;
        try {
            res = run(g, p, a, args);
        } catch (Exception ex) {
            AethoriaEvents.LOG.warn("Action {} : {}", a, ex.toString());
            res = "!Erreur interne : " + ex.getMessage();
        }
        if (SILENT.equals(res)) return;
        boolean err = Admin.isErr(res);
        Net.sendSnapshot(p, null, null, res == null ? null : Admin.text(res).replaceAll("§.", ""), !err);
    }

    private static String run(Game g, ServerPlayer p, String a, CompoundTag x) {
        boolean admin = !(a.equals("class.choose") || a.equals("resupply") || a.equals("request"));
        if (admin && !p.hasPermissions(2)) return "!Permission refusée.";
        switch (a) {
            // ---- navigation
            case "request": {
                String screen = x.getString("screen");
                if (screen.equals("main") && !p.hasPermissions(2)) return "!Permission refusée.";
                if (screen.equals("class") && (!g.running || g.teamOf(p.getUUID()) == null)) return "!Aucun événement en cours ou pas d'équipe.";
                UUID target = null;
                if (screen.equals("stats") && x.contains("target")) target = g.stats.find(x.getString("target"), g.server);
                Net.sendSnapshot(p, screen, target, null, true);
                return SILENT;
            }
            // ---- joueurs
            case "class.choose": {
                EvKit k = g.st.kit(x.getString("kit"));
                if (k == null) return "!Classe introuvable.";
                String r = g.choose(p, k);
                boolean bad = r.startsWith("Aucun") || r.startsWith("Classe indisponible") || r.startsWith("Classe complète");
                return bad ? "!" + r : r;
            }
            case "resupply": {
                String r = g.resupply(p);
                return r.startsWith("§a") ? r : "!" + r;
            }
            // ---- partie
            case "game.start": { String e = g.start(); return e == null ? "Événement lancé." : "!" + e; }
            case "game.stop": if (!g.running) return "!Aucun événement en cours."; g.finish(true); return "Événement arrêté.";
            case "game.go": { String e = g.go(); return e == null ? "Le combat commence !" : "!" + e; }
            case "game.preset": return Admin.preset();
            case "setting": return Admin.setting(x.getString("key"), x.getInt("value"));
            // ---- equipes
            case "team.create": return Admin.teamCreate(x.getString("name"));
            case "team.delete": return Admin.teamDelete(x.getString("name"));
            case "team.rename": return Admin.teamRename(x.getString("name"), x.getString("new"));
            case "team.color": return Admin.teamColor(x.getString("name"), Opts.parseColor(x.getString("color")));
            case "team.spawn": return Admin.teamSpawn(x.getString("name"), p);
            case "team.flag": return Admin.teamFlag(x.getString("name"), p, false);
            case "team.flag.clear": return Admin.teamFlag(x.getString("name"), p, true);
            case "team.class": return Admin.teamClass(x.getString("name"), x.getString("kit"));
            case "team.member": {
                ServerPlayer t = g.player(UUID.fromString(x.getString("uuid")));
                if (t == null) return "!Joueur hors ligne.";
                return Admin.teamMember(t, x.getString("team"));
            }
            // ---- kits
            case "kit.create": return Admin.kitCreate(x.getString("name"), x.getBoolean("fromInv") ? p : null);
            case "kit.delete": return Admin.kitDelete(x.getString("name"));
            case "kit.rename": return Admin.kitRename(x.getString("name"), x.getString("new"));
            case "kit.limit": return Admin.kitLimit(x.getString("name"), x.getInt("delta"));
            case "kit.medic": return Admin.kitMedic(x.getString("name"));
            case "kit.copyinv": return Admin.kitCopyInv(x.getString("name"), p);
            case "kit.clear": return Admin.kitClear(x.getString("name"));
            case "kit.add": return Admin.kitAdd(x.getString("name"), x.getString("item"), x.getInt("count"));
            case "kit.addhand": return Admin.kitAddHand(x.getString("name"), p);
            case "kit.adjust": return Admin.kitAdjust(x.getString("name"), x.getInt("index"), x.getInt("delta"));
            case "kit.remove": return Admin.kitRemove(x.getString("name"), x.getInt("index"));
            case "kit.give": return Admin.kitGive(x.getString("name"), p);
            // ---- zones
            case "zone.create": return Admin.zoneCreate(x.getString("name"), p, 6, 20);
            case "zone.delete": return Admin.zoneDelete(x.getString("name"));
            case "zone.rename": return Admin.zoneRename(x.getString("name"), x.getString("new"));
            case "zone.radius": return Admin.zoneRadius(x.getString("name"), x.getInt("delta"));
            case "zone.seconds": return Admin.zoneSeconds(x.getString("name"), x.getInt("delta"));
            case "zone.type": return Admin.zoneType(x.getString("name"), x.getString("type"));
            case "zone.hq": return Admin.zoneHq(x.getString("name"), x.getString("team"));
            case "zone.move": return Admin.zoneMove(x.getString("name"), p);
            case "zone.tp": { String r = Admin.zoneTp(x.getString("name"), p); return Admin.isErr(r) ? r : SILENT; }
            default: return "!Action inconnue : " + a;
        }
    }
}
