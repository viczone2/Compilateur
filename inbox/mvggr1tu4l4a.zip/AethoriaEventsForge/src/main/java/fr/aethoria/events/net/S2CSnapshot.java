package fr.aethoria.events.net;

import fr.aethoria.events.client.ClientHooks;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

public class S2CSnapshot {
    private final CompoundTag tag;

    public S2CSnapshot(CompoundTag tag) { this.tag = tag; }

    public void encode(FriendlyByteBuf buf) { buf.writeNbt(tag); }

    public static S2CSnapshot decode(FriendlyByteBuf buf) {
        CompoundTag t = buf.readNbt();
        return new S2CSnapshot(t == null ? new CompoundTag() : t);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.snapshot(tag)));
        c.setPacketHandled(true);
    }
}
