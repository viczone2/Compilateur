# AethoriaEvents - mod Forge 1.20.1 (v2.0.0)

Port du plugin AethoriaEvents 1.3.1 en **mod Forge 1.20.1** (Forge 47.x, Java 17) avec de vraies interfaces graphiques.
Le mod doit être installé **sur le serveur ET chez les joueurs** (comme Epic Knights ou Magistu Armory).

## Compiler
1. Installer un JDK 17.
2. Dans ce dossier : `gradle wrapper --gradle-version 8.1.1` (une seule fois), puis `./gradlew build`.
   (Ou ouvrir le dossier dans IntelliJ IDEA : le projet Gradle se configure tout seul.)
3. Le jar est dans `build/libs/aethoriaevents-2.0.0.jar` : à mettre dans `mods/` du serveur et des clients.

> Le code n'a pas pu être compilé dans l'environnement où il a été écrit (pas d'accès à Forge).
> Si Gradle signale une erreur de compilation, envoie-moi le message : ce sera une correction d'une ligne.

## Interfaces
| Ouvrir | Contenu |
|---|---|
| `/event gui` (op) | Tableau de bord : état de la partie, lancer / arrêter, préréglage |
| Équipes | Liste, couleurs (palette), renommer, respawn, drapeau, classes autorisées, membres (joueurs en ligne) |
| Kits et classes | Grille d'objets, catalogue de **tous** les objets (vanilla + mods) avec recherche et filtre par mod, copie d'inventaire, limite, rôle de médecin, test |
| Zones | Type (Normale / Dépôt / QG), équipe du QG, rayon, temps de capture, déplacer, téléporter |
| Réglages | Tous les réglages de la partie, regroupés, avec interrupteurs et boutons − / + (Maj = ×5) |
| `/classe` (joueurs) | Choix de classe avec limites et aperçu du contenu |
| `/stats [joueur]` | Classement de la manche + statistiques cumulées (s'ouvre aussi en fin de partie) |

En partie, un **HUD** affiche chrono, scores, zones (avec barre de capture), classe et état « à terre ».

## Commandes
`/event gui|start|go|stop|preset|team|zone|kit|spectate|set` (alias `/ev`, niveau op 2), `/classe`, `/ravitaillement` (`/ravit`), `/stats`.
Les commandes du plugin d'origine sont conservées (`/event team create ...`, `/event set duration-minutes 20`, etc.).
Seule nouveauté : `/event kit edit <kit>` ouvre l'éditeur de kit.

## Différences avec le plugin
- Plus de menus-coffre ni de saisie dans le chat : tout passe par les interfaces (champs de texte intégrés).
- Plus de scoreboard latéral : remplacé par le HUD (le contour de couleur des joueurs reste via les équipes de scoreboard).
- Les joueurs ne **meurent plus vraiment** pendant l'événement : coup mortel = « à terre » (si activé) puis élimination -> spectateur -> réapparition à la base. Pas de drops, pas d'écran de mort.
- Noms d'équipes / kits / zones : lettres, chiffres, `_` et `-` (sans espace) pour rester utilisables en commande.
- Pendant une partie, la création / suppression / renommage d'équipes, kits et zones est bloquée (réglages et positions restent modifiables).
- Permissions : niveau op 2 (pas de permission `aethoriaevents.admin`).

## Données
`config/aethoriaevents/data.json` (équipes, kits, zones, réglages) et `stats.json`. Les kits y sont stockés avec leurs NBT complets.
Le fichier de l'ancien plugin (`plugins/AethoriaEvents/`) n'est pas importé automatiquement.
