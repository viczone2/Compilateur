# Fix for “Projet non reconnu (pas de pom.xml ni de build.gradle)”

The project is an Android Gradle project nested under `android/`. Some generic online compilers only scan the ZIP root, so they do not detect it.

## Correct way to build the APK
1. Extract this ZIP.
2. In Android Studio, choose **Open** and select the `android/` folder (not the ZIP root and not `backend/`).
3. Wait for Gradle sync, then use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## If your compiler requires `build.gradle` at ZIP root
This package now includes root `build.gradle` and `settings.gradle` marker files so the archive is recognized by basic scanners. However, a generic Java/Maven compiler still cannot compile an Android app unless it supports Android Gradle Plugin, Android SDK 35, and Java 17.

## Backend
The Python API in `backend/` is not an Android build system and does not compile the APK. It is a starter API scaffold only.
