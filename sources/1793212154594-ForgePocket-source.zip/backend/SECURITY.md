# Before enabling real compilation

This API intentionally does not compile uploads. Before adding workers:

1. Require authentication and authorization for every request.
2. Run each build in a disposable container/VM with no host mounts, no privileged mode, no Docker socket, strict CPU/RAM/time/disk limits and a read-only base filesystem.
3. Disable outbound network access by default. Dependency fetching, if required, should use a controlled proxy/cache.
4. Validate archive paths and unpack only in the isolated worker; reject path traversal, symlinks and oversized archives.
5. Never run a produced `.exe` on the API server.
6. Store artifacts outside the web root and use short-lived, authenticated download links.
7. Add job cleanup, audit logs, rate limits, queue limits and malware scanning.
8. Do not use the in-memory job dictionary in production; use a database and queue.
