from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from pathlib import Path
from uuid import uuid4
import os
import zipfile

app = FastAPI(title="ForgePocket Build API", version="0.1.0")
UPLOAD_DIR = Path(os.environ.get("FORGEPOCKET_UPLOAD_DIR", "/tmp/forgepocket-uploads"))
MAX_BYTES = int(os.environ.get("FORGEPOCKET_MAX_UPLOAD_BYTES", str(50 * 1024 * 1024)))
ALLOWED_TARGETS = {"android-apk", "minecraft-plugin", "minecraft-mod", "windows-exe"}
jobs = {}

@app.get("/health")
def health():
    return {"status": "ok", "builder_configured": False}

@app.get("/targets")
def targets():
    return {"targets": [
        {"id": "android-apk", "label": "APK Android", "examples": ["Gradle Android project"]},
        {"id": "minecraft-plugin", "label": "Plugin Minecraft", "examples": ["Paper/Spigot Maven or Gradle project"]},
        {"id": "minecraft-mod", "label": "Mod Minecraft", "examples": ["Forge/Fabric Gradle project"]},
        {"id": "windows-exe", "label": "Windows executable", "examples": [".NET or CMake project"]}
    ]}

@app.post("/builds")
async def create_build(target: str = Form(...), source: UploadFile = File(...)):
    if target not in ALLOWED_TARGETS:
        raise HTTPException(400, "Unsupported target.")
    if not source.filename or not source.filename.lower().endswith(".zip"):
        raise HTTPException(400, "Upload a ZIP archive of the source project.")
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    job_id = str(uuid4())
    destination = UPLOAD_DIR / f"{job_id}.zip"
    total = 0
    try:
        with destination.open("wb") as out:
            while True:
                chunk = await source.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > MAX_BYTES:
                    raise HTTPException(413, f"Archive exceeds {MAX_BYTES} bytes.")
                out.write(chunk)
        # Validate ZIP structure only; never extract or execute untrusted source here.
        if not zipfile.is_zipfile(destination):
            raise HTTPException(400, "The uploaded file is not a valid ZIP archive.")
        jobs[job_id] = {
            "job_id": job_id,
            "target": target,
            "status": "waiting_for_worker",
            "message": "Archive received, but no isolated build worker is configured.",
            "artifact_url": None
        }
        return {
            "job_id": job_id,
            "status": "waiting_for_worker",
            "message": "Archive reçue. Le serveur n’a pas encore de compilateur isolé configuré."
        }
    except Exception:
        destination.unlink(missing_ok=True)
        raise
    finally:
        await source.close()

@app.get("/builds/{job_id}")
def get_build(job_id: str):
    if job_id not in jobs:
        raise HTTPException(404, "Unknown build job.")
    return jobs[job_id]
