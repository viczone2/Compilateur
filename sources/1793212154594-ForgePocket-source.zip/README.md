# ForgePocket — source code

ForgePocket is an Android starter project for managing builds from source code:
- Android APK projects
- Minecraft plugins (Paper/Spigot)
- Minecraft mods (Forge/Fabric)
- Windows `.exe` projects (for example, .NET or CMake projects)

## Important limitation

A phone cannot reliably compile every one of these formats by itself. ForgePocket is designed as an Android client plus a separate build server. The Android app imports a ZIP source archive, selects a target and sends it to a build API. The included API is a **safe starter scaffold**, not a production build farm: its build endpoint deliberately returns a clear “builder not configured” response until you install and configure isolated build workers.

Do not expose a build server publicly without authentication, strict resource limits, network restrictions and per-job sandboxing. Source archives are untrusted input.

## Project structure

- `android/` — Android app (Kotlin, Jetpack Compose)
- `backend/` — FastAPI API scaffold
- `backend/Dockerfile` — API container (not a compiler image)
- `backend/requirements.txt`

## Android build

Open `android/` in Android Studio (recent version), let Gradle sync, then build the `app` module.
The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21 and compile SDK 35.

In the app, set the API URL to your server's base URL, e.g. `https://build.example.com`.
For local testing with an emulator, use `http://10.0.2.2:8000`; for a physical phone, use your computer's LAN IP and ensure the phone and computer share a network. Cleartext HTTP is enabled only for development in the manifest.

## Backend development

```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

API:
- `GET /health`
- `GET /targets`
- `POST /builds` — accepts a ZIP source archive and target; currently reports that no isolated build worker is configured.
- `GET /builds/{job_id}` — reports job state.

## What is and isn't implemented

Implemented: project ZIP selection, target selection, upload request, job status polling, clean UI, API scaffold and API documentation.
Not implemented: actual compilers/build workers, user accounts, production authentication, artifact downloads, cloud storage, billing or Windows executable execution. The app does not run uploaded EXEs.
