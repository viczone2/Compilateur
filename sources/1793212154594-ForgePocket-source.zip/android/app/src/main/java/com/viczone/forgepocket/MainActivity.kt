package com.viczone.forgepocket

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ForgePocketApp() }
    }
}

private val ink = Color(0xFF101828)
private val accent = Color(0xFF6D5DFB)
private val panel = Color(0xFFF2F4F7)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ForgePocketApp() {
    var target by remember { mutableStateOf("minecraft-plugin") }
    var apiUrl by remember { mutableStateOf("http://10.0.2.2:8000") }
    var selectedName by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Importe un ZIP de code source pour commencer.") }
    var jobId by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var zipUri by remember { mutableStateOf<Uri?>(null) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            zipUri = uri
            selectedName = uri.lastPathSegment?.substringAfterLast('/') ?: "source.zip"
            status = "Archive sélectionnée. Prête à être envoyée."
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = accent, background = Color.White)) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("ForgePocket", fontWeight = FontWeight.Bold, color = ink)
                            Text("Compile tes projets depuis ton téléphone", fontSize = 12.sp, color = Color.Gray)
                        }
                    },
                    actions = {
                        IconButton(onClick = { status = "Configure l’URL de ton API de compilation ci-dessous." }) {
                            Icon(Icons.Default.Settings, contentDescription = "Paramètres")
                        }
                    }
                )
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().background(Color.White).padding(padding)
                    .verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Card(colors = CardDefaults.cardColors(containerColor = ink), shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("TON ATELIER DE BUILD", color = Color(0xFFB8B3FF), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("Du code source\nà un artefact.", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold, lineHeight = 32.sp)
                        Text("APK · Plugins · Mods · Windows", color = Color(0xFFD0D5DD))
                    }
                }

                Text("1. Type de projet", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = ink)
                val targets = listOf(
                    "APK Android" to "android-apk",
                    "Plugin Minecraft" to "minecraft-plugin",
                    "Mod Minecraft" to "minecraft-mod",
                    "Programme Windows (.exe)" to "windows-exe"
                )
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    targets.forEach { (label, value) ->
                        val chosen = target == value
                        Surface(
                            onClick = { target = value },
                            shape = RoundedCornerShape(14.dp),
                            color = if (chosen) Color(0xFFEEECFF) else panel,
                            border = if (chosen) androidx.compose.foundation.BorderStroke(1.dp, accent) else null
                        ) {
                            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Code, contentDescription = null, tint = if (chosen) accent else Color.Gray)
                                Spacer(Modifier.width(12.dp))
                                Text(label, Modifier.weight(1f), fontWeight = if (chosen) FontWeight.SemiBold else FontWeight.Normal)
                                RadioButton(selected = chosen, onClick = { target = value })
                            }
                        }
                    }
                }

                Text("2. Code source", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = ink)
                OutlinedButton(onClick = { picker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                    Icon(Icons.Default.FolderOpen, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (selectedName.isBlank()) "Choisir une archive ZIP" else selectedName)
                }
                Text("Compresse le dossier du projet en ZIP, avec les fichiers Gradle, Maven, source, etc.", fontSize = 12.sp, color = Color.Gray)

                Text("3. Serveur de compilation", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = ink)
                OutlinedTextField(
                    value = apiUrl, onValueChange = { apiUrl = it.trim() },
                    label = { Text("URL de l'API") }, modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Text("Pour un émulateur : http://10.0.2.2:8000. Pour un vrai téléphone, utilise l’adresse IP de ton PC ou l’URL HTTPS de ton serveur.", fontSize = 12.sp, color = Color.Gray)

                Button(
                    onClick = {
                        val uri = zipUri
                        if (uri == null) {
                            status = "Choisis d’abord une archive ZIP."
                        } else {
                            busy = true
                            status = "Envoi de l’archive au serveur…"
                            scope.launch {
                                val result = withContext(Dispatchers.IO) {
                                    try {
                                        val temp = File(context.cacheDir, "forgepocket-source.zip")
                                        context.contentResolver.openInputStream(uri)?.use { input ->
                                            temp.outputStream().use { output -> input.copyTo(output) }
                                        } ?: error("Impossible de lire le fichier.")
                                        val client = OkHttpClient.Builder()
                                            .callTimeout(120, TimeUnit.SECONDS).build()
                                        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
                                            .addFormDataPart("target", target)
                                            .addFormDataPart("source", selectedName.ifBlank { "source.zip" },
                                                temp.asRequestBody("application/zip".toMediaType()))
                                            .build()
                                        val request = Request.Builder().url(apiUrl.trimEnd('/') + "/builds").post(body).build()
                                        client.newCall(request).execute().use { response ->
                                            val text = response.body?.string().orEmpty()
                                            if (!response.isSuccessful) error("API ${response.code}: $text")
                                            val json = JSONObject(text)
                                            Pair(json.optString("job_id"), json.optString("message", "Demande reçue."))
                                        }
                                    } catch (e: Exception) {
                                        Pair("", "Erreur : ${e.message ?: "connexion impossible"}. Vérifie l’URL et le serveur.")
                                    }
                                }
                                jobId = result.first
                                status = result.second
                                busy = false
                            }
                        }
                    },
                    enabled = !busy, modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    if (busy) CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                    else Icon(Icons.Default.CloudUpload, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (busy) "Envoi…" else "Envoyer pour compilation")
                }

                Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("État du projet", fontWeight = FontWeight.Bold, color = ink)
                        Text(status, color = Color(0xFF344054))
                        if (jobId.isNotBlank()) Text("Job : $jobId", fontSize = 12.sp, color = Color.Gray)
                    }
                }

                Text("Sécurité : n’envoie que du code auquel tu fais confiance. Le serveur doit compiler dans un environnement isolé. ForgePocket ne lance pas les fichiers .exe.", fontSize = 12.sp, color = Color.Gray)
                Spacer(Modifier.height(12.dp))
            }
        }
    }
}
